#Paper: Recreational visits to marine environments in England: Where, what, who, why and when?
#Target journal: Marine Policy (SI)
#Project: BlueHealth
#Authors: Lewis Elliott, James Grellier, Mathew White, Sian Rees, and Lora Fleming
#Date created: 20170613
#Date last updated: 20170627

rm(list=ls()) # Clear workspace

setwd ("U:/20160301_BH/20160803_Data&Papers/20160803_BlueRecWWWWW/20170613_Y1-7MENEData") # Set working directory
dir() # View working directory

meneRaw <- read.csv("MENE Year 7 Visit CSV file.CSV", header = TRUE) # Reads in data and labels it "meneRaw"
write(colnames(meneRaw), file = "variable names.txt") # Produces a txt file of column names (variable names)

# Sorting out visit dates

summary(meneRaw$Visitdate) # Requires conversion to a "date" object
meneRaw$Visitdate[which(meneRaw$Visitdate==" ")] <- NA # Missing visit dates (due to non-followed-up visits) are given an "NA" value
meneRaw$Visitdate_date <- as.Date(meneRaw$Visitdate, format = "%m/%d/%Y") # Converts valid cells into date format (mm/dd/yyyy)
summary(meneRaw$Visitdate_date) # Summarises the new variable

# Creating a new data frame of only those visits which were randomly selected for follow-up

summary(meneRaw$selvisit) # Summarises the "selected visit" variable
dim(meneRaw) # Retrieves the dimensions of the original data frame
meneFiltered <- meneRaw[which(meneRaw$selvisit=="1"),] # This creates a new object "mene Filtered", which selects only those visits where
# "selvisit" variable is exactly equal to "1" (indicating 'yes') in the original data frame.
# The comma is required because we are subsetting by rows (before the comma)
# and not columns (which would come after the comma)
dim(meneFiltered) # Retrieves the dimensions of the new data frame
summary(meneFiltered$selvisit) # Summarises the selvisit variable in the new data frame to check all cases are "Yeses"

# Creating a 'coastal' category which collapses visits to "a beach" and "other coastline"

meneFiltered$Coastal <- NA # Creates a new variable and labels all entries "NA"
meneFiltered$Coastal[which(meneFiltered$Q5_14=="1" |
                             meneFiltered$Q5_15=="1")] <- "Yes" # Asks the new variable to be "Yes" when "a beach" or "other coastline" equal 1.
meneFiltered$Coastal[which(meneFiltered$Q5_14=="0" &
                             meneFiltered$Q5_15=="0")] <- "No" # Asks the new variable to be "No" when "a beach" and "other coastline" equal 0.
meneFiltered$Coastal <- factor(meneFiltered$Coastal, levels = c("No", "Yes")) # Asks the new variable to be a factor with 2 levels; "yes" and "no"
summary(meneFiltered$Coastal) # Summarises the new 'coastal' variable.

# Creating a weekend/weekday variable

meneFiltered$Visitdate_day <- as.factor(weekdays(meneFiltered$Visitdate_date)) # Creates a new variable, labels it as a factor and tells is to draw out
# weekdays from the visit date variable
summary(meneFiltered$Visitdate_day) # Summarises this new variable
meneFiltered$Visitdate_weekend <- "No" # Creates a new variable called "Visitdate_weekend." All entries are set to "No."
meneFiltered$Visitdate_weekend[which(meneFiltered$Visitdate_day=="Saturday"|
                                       meneFiltered$Visitdate_day=="Sunday")] <- "Yes" # Asks the new variable to equal "Yes" when visit was a weekend day
meneFiltered$Visitdate_weekend <- factor(meneFiltered$Visitdate_weekend, levels = c("No", "Yes")) # Turns the new variable into a factor with two levels
summary(meneFiltered$Visitdate_weekend) # Summarises this new variable

# Creating a crude 'season' variable

meneFiltered$Season <- NA # Creates a new variable - "Season"
meneFiltered$Season[which(months(meneFiltered$Visitdate_date)=="December"|
                            months(meneFiltered$Visitdate_date)=="January"|
                            months(meneFiltered$Visitdate_date)=="February")] <- "Winter" # Extracts the months from the visit date variable and labels
# these three months as Winter.
meneFiltered$Season[which(months(meneFiltered$Visitdate_date)=="March"|
                            months(meneFiltered$Visitdate_date)=="April"|
                            months(meneFiltered$Visitdate_date)=="May")] <- "Spring" # Extracts the months from the visit date variable and labels these
# these three months as Spring.
meneFiltered$Season[which(months(meneFiltered$Visitdate_date)=="June"|
                            months(meneFiltered$Visitdate_date)=="July"|
                            months(meneFiltered$Visitdate_date)=="August")] <- "Summer" # Extracts the months from the visit date variable and labels
# these three months as Summer.
meneFiltered$Season[which(months(meneFiltered$Visitdate_date)=="September"|
                            months(meneFiltered$Visitdate_date)=="October"|
                            months(meneFiltered$Visitdate_date)=="November")] <- "Autumn" # Extracts the months from the visit dat variable and labels
# these three months as Autumn.
meneFiltered$Season <- factor(meneFiltered$Season, levels = c("Winter", "Spring", "Summer", "Autumn")) # Asks the new variable to be a 4-level factor
summary(meneFiltered$Season) # Summarises the new season variable.

# Create health motive variable by collapsing across question frequency in the different waves

meneFiltered$healthmotivecombined <- NA # Creates a new variable and labels all entries as "NA"
meneFiltered$healthmotivecombined[which(meneFiltered$q12_05Y4Y6=="1"|
                                          meneFiltered$q12_5Y1Y3=="1")] <- "Yes" # The new variable equals "Yes" when the previous two equalled "1"
# NB The "Y4-6 in the variable name is obviously a mistype by NE
# - should be Y4-7 presumably.
meneFiltered$healthmotivecombined[which(meneFiltered$q12_05Y4Y6=="0"|
                                          meneFiltered$q12_5Y1Y3=="0")] <- "No"  # The new variable equals "No" when the previous 2 equalled "0".
meneFiltered$healthmotivecombined <- factor(meneFiltered$healthmotivecombined, levels = c("Yes", "No")) # The new variable is a two-level factor
summary(meneFiltered$healthmotivecombined) # Summarises the new variable

#Create a relax motive variable by collapsing across question frequency in the different waves

meneFiltered$relaxmotivecombined <- NA # Creates a new variable and labels all new entries as "NA"
meneFiltered$relaxmotivecombined[which(meneFiltered$q12_07Y4Y6=="1"|
                                         meneFiltered$q12_7Y1Y3=="1")] <- "Yes" # New variable equals "Yes" when old two equalled "1".
meneFiltered$relaxmotivecombined[which(meneFiltered$q12_07Y4Y6=="0"|
                                         meneFiltered$q12_7Y1Y3=="0")] <- "No" # New variable equals "No" when old two equalled "0".
meneFiltered$relaxmotivecombined <- factor(meneFiltered$relaxmotivecombined, levels = c("Yes", "No")) # The new variable is a two-level factor
summary(meneFiltered$relaxmotivecombined) # Summarises the new variable

# Create a family motive variable by collapsing across question frequency in the different waves

meneFiltered$familymotivecombined <- NA # Creates a new variable and labels all new entried as "NA"
meneFiltered$familymotivecombined[which(meneFiltered$q12_01Y4Y6=="1"|
                                          meneFiltered$q12_1Y1Y3=="1")] <- "Yes" # New variable equals "Yes" when old two equalled "1".
meneFiltered$familymotivecombined[which(meneFiltered$q12_01Y4Y6=="0"| 
                                          meneFiltered$q12_1Y1Y3=="0")] <- "No" # New variable equals "No" when old two equalled "0".
meneFiltered$familymotivecombined <- factor(meneFiltered$familymotivecombined, levels = c("Yes", "No")) # The new variable is a two-level factor
summary(meneFiltered$familymotivecombined) # Summarisese the new variable

# Create a friend motive variable by collapsing across question frequency in the different waves

meneFiltered$friendmotivecombined <- NA # Creates a new variable and labels all new entries as "NA"
meneFiltered$friendmotivecombined[which(meneFiltered$q12_02Y4Y6=="1"|
                                          meneFiltered$q12_2Y1Y3=="1")] <- "Yes" # New variable equals "Yes" when old two equalled "1".
meneFiltered$friendmotivecombined[which(meneFiltered$q12_02Y4Y6=="0"|
                                          meneFiltered$q12_2Y1Y3=="0")] <- "No" # New variable equals "No" when old two equalled "0".
meneFiltered$friendmotivecombined <- factor(meneFiltered$friendmotivecombined, levels = c("Yes", "No")) # The new variable is a two-level factor
summary(meneFiltered$friendmotivecombined) # Summarises the new variable

# Create a social motive by combining the new family and friend motive variables

meneFiltered$socialmotive <- NA # Creates a new variable and labels all entries as "NA"
meneFiltered$socialmotive[which(meneFiltered$familymotivecombined=="Yes"|
                                  meneFiltered$friendmotivecombined=="Yes")] <- "Yes" # The new variable equals "Yes" when the old two equalled "Yes"
meneFiltered$socialmotive[which(meneFiltered$familymotivecombined=="No"&
                                  meneFiltered$friendmotivecombined=="No")] <- "No" # The new variable equals "No" when the old two equalled "No"
meneFiltered$socialmotive <- factor(meneFiltered$socialmotive, levels = c("Yes", "No")) # The new variable is a two-level factor
summary(meneFiltered$socialmotive) # Summarises the new variable

# Create a new age variable with three categories

meneFiltered$age_3_cats <- NA # Creates a new variable with all entries as "NA"
meneFiltered$age_3_cats[which(meneFiltered$age=="1"|
                                meneFiltered$age=="2")] <- c("16-34") # New variable equals "16-34" where old variable equalled "1" and "2".
meneFiltered$age_3_cats[which(meneFiltered$age=="3"|
                                meneFiltered$age=="4"|
                                meneFiltered$age=="5")] <- c("35-64") # New variable equals "35-64" where old variable equalled "3", "4", or "5".
meneFiltered$age_3_cats[which(meneFiltered$age=="6")] <- c("65+") # New variable equals "65+" where old variable equalled "6".
meneFiltered$age_3_cats <- factor(meneFiltered$age_3_cats, levels = c("35-64", "16-34", "65+")) # New variable is a three-level factor.
summary(meneFiltered$age_3_cats) # Summarises the new variable

# Create a new walking category collapsing with and without dogs

meneFiltered$walk <- NA # Creates a new variable with all entries as "NA"
meneFiltered$walk[which(meneFiltered$q4_15=="1"|
                          meneFiltered$q4_16=="1")] <- "Yes" # The new variable equals "Yes" when walk w/dog and walk w/o dog equalled "1".
meneFiltered$walk[which(meneFiltered$q4_15=="0"&
                          meneFiltered$q4_16=="0")] <- "No" # The new variable equals "No" when walk w/dog and walk w/o dog equalled "0".
meneFiltered$walk <- factor(meneFiltered$walk, levels = c("Yes", "No")) # New variable is a two-level factor
summary(meneFiltered$walk) # Summarises the new variable

# Creating a walking at the coast variable

meneFiltered$coastwalk <- NA # Creates a new variable with all entries as NA
meneFiltered$coastwalk[which(meneFiltered$Coastal=="Yes"&
                               meneFiltered$walk=="Yes")] <- "Yes" # Where coastal=Yes and walk=Yes, coastwalk=Yes.
meneFiltered$coastwalk[which(meneFiltered$Coastal=="No"|
                               meneFiltered$walk=="No")] <- "No"
meneFiltered$coastwalk <- factor(meneFiltered$coastwalk, levels = c("No", "Yes")) # New variable is a two-level factor
summary(meneFiltered$coastwalk) # Summarises the new variable

# Creating a walking in inland waters variable

meneFiltered$inlandwaterwalk <- NA # Creates a new variable with all entries as NA
meneFiltered$inlandwaterwalk[which(meneFiltered$Q5_04=="1"&
                                     meneFiltered$walk=="Yes")] <- "Yes" # The new variable equals yes when walk=Yes and Q5_04 (river, lake, canal)=1.
meneFiltered$inlandwaterwalk[which(meneFiltered$Q5_04=="0"|
                                     meneFiltered$walk=="No")] <- "No" 
meneFiltered$inlandwaterwalk <- factor(meneFiltered$inlandwaterwalk, levels = c("No", "Yes")) # New variable is a two-level factor
summary(meneFiltered$inlandwaterwalk) # Summarises the new variable

# Creating a walking in parks variable

meneFiltered$parkwalk <- NA # Creates a new variable with all entries as NA
meneFiltered$parkwalk[which(meneFiltered$Q5_09=="1"&
                              meneFiltered$walk=="Yes")] <- "Yes" # The new variable equals yes when walk=yes and Q5_09 (park)=1.
meneFiltered$parkwalk[which(meneFiltered$Q5_09=="0"|
                              meneFiltered$walk=="No")] <- "No"
meneFiltered$parkwalk <- factor(meneFiltered$parkwalk, levels = c("No", "Yes")) # New variable is a two-level factor
summary(meneFiltered$parkwalk) # Summarises the new variable

# Creating a walking in woods variable

meneFiltered$woodswalk <- "No" # Creates a new variable with all entries as NA
meneFiltered$woodswalk[which(meneFiltered$Q5_01=="1"&
                               meneFiltered$walk=="Yes")] <- "Yes" # The new variable equals yes when walk=yes and Q5_01 (woods)=1.
meneFiltered$woodswalk[which(meneFiltered$Q5_01=="0"|
                               meneFiltered$walk=="No")] <- "No"
meneFiltered$woodswalk <- factor(meneFiltered$woodswalk, levels = c("No", "Yes")) # New variable is a two-level factor
summary(meneFiltered$woodswalk) # Summarises the new variable

# Creating a fishing in coastal areas variable

meneFiltered$coastfish <- NA # Creates a new variable with all entries as NA
meneFiltered$coastfish[which(meneFiltered$q4_03=="1"&
                               meneFiltered$Coastal=="Yes")] <- "Yes" # The new variable equals yes when q4_03 (fishing)=1 and Coastal=Yes.
meneFiltered$coastfish[which(meneFiltered$q4_03=="0"|
                               meneFiltered$Coastal=="No")] <- "No"
meneFiltered$coastfish <- factor(meneFiltered$coastfish, levels = c("No", "Yes")) # New variable is a two-level factor
summary(meneFiltered$coastfish) # Summarises the new variable

# Creating a watersports in coastal areas variable

meneFiltered$coastwatersports <- NA # Creates a new variable with all entries as NA
meneFiltered$coastwatersports[which(meneFiltered$q4_17=="1"&
                                      meneFiltered$Coastal=="Yes")] <- "Yes" # The new variable equals yes when q4_17 (watersports)=1 and Coastal=Yes.
meneFiltered$coastwatersports[which(meneFiltered$q4_17=="0"|
                                      meneFiltered$Coastal=="No")] <- "No"
meneFiltered$coastwatersports <- factor(meneFiltered$coastwatersports, levels = c("No", "Yes")) # New variable is a two-level factor
summary(meneFiltered$coastwatersports) # Summarises the new variable

# Creating a swimming in coastal areas variable

meneFiltered$coastswim <- NA # Creates a new variable with all entries as NA
meneFiltered$coastswim[which(meneFiltered$q4_12=="1"&
                               meneFiltered$Coastal=="Yes")] <- "Yes" # The new variable equals yes when q4_12 (swim)=1 and Coastal=Yes.
meneFiltered$coastswim[which(meneFiltered$q4_12=="0"|
                               meneFiltered$Coastal=="No")] <- "No"
meneFiltered$coastswim <- factor(meneFiltered$coastswim, levels = c("No", "Yes")) # New variable is a two-level factor
summary(meneFiltered$coastswim) # Summarises the new variable

# Creating a sunbathing/paddling in coastal areas variable

meneFiltered$coastlobster <- NA # Creates a new variable with all entries as NA
meneFiltered$coastlobster[which(meneFiltered$q4_13=="1"&
                                  meneFiltered$Coastal=="Yes")] <- "Yes" # The new variable equals yes when q4_13 (sunbathing/paddling)=1 and Coastal=Yes.
meneFiltered$coastlobster[which(meneFiltered$q4_13=="0"|
                                  meneFiltered$Coastal=="No")] <- "No"
meneFiltered$coastlobster <- factor(meneFiltered$coastlobster, levels = c("No", "Yes")) # New variable is a two-level factor
summary(meneFiltered$coastlobster) # Summarises the new variable

# Turning the MENE region variable into a factor and labelling its levels

meneFiltered$RESIDENCE_REGION <- factor(meneFiltered$RESIDENCE_REGION,
                                        levels = c("1", "2", "3", "5", "6", "7", "8", "9", "10"),
                                        labels = c("East Midlands", "East of England", "London", "North East",
                                                   "North West", "South East", "South West", "West Midlands",
                                                   "Yorkshire and The Humber")) # Asribes the values the correct region names
summary(meneFiltered$RESIDENCE_REGION) # Summarises the new variable (NB 3,144 NA's - unsure why)

#Turning sex into a factor and labelling its levels

meneFiltered$sex <- factor(meneFiltered$sex,
                           levels = c("1", "2"),
                           labels = c("Male", "Female")) # Ascribes the values the correct sex names
summary(meneFiltered$sex) # Summarises the new variable

#Turning segcombine into a factor and labelling its levels

meneFiltered$segcombine <- factor(meneFiltered$segcombine,
                                  levels = c("1", "2", "3", "4"),
                                  labels = c("AB", "C1", "C2", "DE")) # Ascribes the values the correct seg names
summary(meneFiltered$segcombine) # Summarises the new variable

#Turning year into a factor and labelling its levels

meneFiltered$year <- factor(meneFiltered$year,
                            levels = c("1", "2", "3", "4", "5", "6", "7"),
                            labels = c("2009-2010", "2010-2011", "2011-2012", "2012-2013",
                                       "2013-2014", "2014-2015", "2015-2016")) # Ascribes the values the correct year names
summary(meneFiltered$year) # Summarises the new variable

# Turning Q5_14 (beach) into a factor and labelling its levels

meneFiltered$Q5_14 <- factor(meneFiltered$Q5_14,
                             levels = c("0", "1"),
                             labels = c("No", "Yes")) # Ascribes the the correct nominal responses and turns it into a factor
summary(meneFiltered$Q5_14) # Summarises the new variable

# Turning Q5_15 (othercoast) into a factor and labelling its levels

meneFiltered$Q5_15 <- factor(meneFiltered$Q5_15,
                             levels = c("0", "1"),
                             labels = c("No", "Yes")) # Ascribes the the correct nominal responses and turns it into a factor
summary(meneFiltered$Q5_15) # Summarises the new variable

# Turning Q5_04 (river, lake, or canal) into a factor and labelling its levels

meneFiltered$Q5_04 <- factor(meneFiltered$Q5_04,
                             levels = c("0", "1"),
                             labels = c("No", "Yes")) # Ascribes the the correct nominal responses and turns it into a factor
summary(meneFiltered$Q5_04) # Summarises the new variable

# Turning Q5_09 (park) into a factor and labelling its levels

meneFiltered$Q5_09 <- factor(meneFiltered$Q5_09,
                             levels = c("0", "1"),
                             labels = c("No", "Yes")) # Ascribes the the correct nominal responses and turns it into a factor
summary(meneFiltered$Q5_09) # Summarises the new variable

# Turning Q5_01 (woods) into a factor and labelling its levels

meneFiltered$Q5_01 <- factor(meneFiltered$Q5_01,
                             levels = c("0", "1"),
                             labels = c("No", "Yes")) # Ascribes the the correct nominal responses and turns it into a factor
summary(meneFiltered$Q5_01) # Summarises the new variable

# Replace zero weights with "NA"

meneFiltered$MonthVweight[meneFiltered$MonthVweight==0] <- NA # Replaces zeros with NAs in month weight variable
meneFiltered$WeekVweight[meneFiltered$WeekVweight==0] <- NA # Replaces zeros with NAs in week weight variable

# Write updated variable name list

write(x = colnames(meneFiltered), file = "variable names updated.txt") # Writes a new text file to the working directory with updated variable names

############ END OF VARIABLE CREATION ############

# Unweighted logistic regressions

# Creating a function for calculating pseudo R2s (credit to Andy Field "Discovering Statistics Using R")

logisticPseudoR2s <- function(LogModel) {
  dev <- LogModel$deviance
  nullDev <- LogModel$null.deviance
  modelN <- length(LogModel$fitted.values)
  R.l <- 1 - dev / nullDev
  R.cs <- 1- exp ( -(nullDev - dev) / modelN)
  R.n <- R.cs / (1 - (exp (-(nullDev / modelN))))
  cat ("Pseudo R^2 for logisitc regression\n")
  cat ("Hosmer and Lemeshow R^2 ", round (R.l, 3), "\n")
  cat ("Cox and Snell R^2 ", round(R.cs, 3), "\n")
  cat ("Nagelkerke R^2 ", round(R.n, 3), "\n")
}

options(scipen = 999) # gets rid of annoying exponent notation

# Predicting beach visits

beachlogistic <- glm(Q5_14 ~ 
                       I(sex=="Female") +
                       I(age_3_cats=="16-34") +
                       I(age_3_cats=="65+") +
                       I(segcombine=="C1") +
                       I(segcombine=="C2") +
                       I(segcombine=="DE") +
                       I(healthmotivecombined=="Yes") +
                       I(relaxmotivecombined=="Yes") +
                       I(socialmotive=="Yes") +
                       I(Visitdate_weekend=="Yes") +
                       I(Season=="Spring") +
                       I(Season=="Summer") +
                       I(Season=="Autumn") +
                       I(year=="2010-2011") +
                       I(year=="2011-2012") +
                       I(year=="2012-2013") +
                       I(year=="2013-2014") +
                       I(year=="2014-2015") +
                       I(year=="2015-2016") +
                       I(RESIDENCE_REGION=="East Midlands") +
                       I(RESIDENCE_REGION=="East of England") +
                       I(RESIDENCE_REGION=="North East") +
                       I(RESIDENCE_REGION=="North West") +
                       I(RESIDENCE_REGION=="South East") +
                       I(RESIDENCE_REGION=="South West") +
                       I(RESIDENCE_REGION=="West Midlands") +
                       I(RESIDENCE_REGION=="Yorkshire and The Humber"),
                     data = meneFiltered, family = binomial) # saves the logistic regression as an object
nobs(beachlogistic) # pulls out the observed n
sum(beachlogistic$y==1) # pulls out how many 'Yeses' there are in the regression 
summary(beachlogistic) # pulls out the p-values
coefbeach <- as.matrix(exp(coef(beachlogistic))) # saves coefficeints as a matrix object
confintbeach <- exp(confint.default(beachlogistic)) # saves CIs as a matrix object
cbind(coefbeach, confintbeach) # displays regression table (ORs and CIs)
logisticPseudoR2s(beachlogistic) # display psuedo R2 statistics

# Predicting other coast visits

othercoastlogistic <- glm(Q5_15 ~ 
                            I(sex=="Female") +
                            I(age_3_cats=="16-34") +
                            I(age_3_cats=="65+") +
                            I(segcombine=="C1") +
                            I(segcombine=="C2") +
                            I(segcombine=="DE") +
                            I(healthmotivecombined=="Yes") +
                            I(relaxmotivecombined=="Yes") +
                            I(socialmotive=="Yes") +
                            I(Visitdate_weekend=="Yes") +
                            I(Season=="Spring") +
                            I(Season=="Summer") +
                            I(Season=="Autumn") +
                            I(year=="2010-2011") +
                            I(year=="2011-2012") +
                            I(year=="2012-2013") +
                            I(year=="2013-2014") +
                            I(year=="2014-2015") +
                            I(year=="2015-2016") +
                            I(RESIDENCE_REGION=="East Midlands") +
                            I(RESIDENCE_REGION=="East of England") +
                            I(RESIDENCE_REGION=="North East") +
                            I(RESIDENCE_REGION=="North West") +
                            I(RESIDENCE_REGION=="South East") +
                            I(RESIDENCE_REGION=="South West") +
                            I(RESIDENCE_REGION=="West Midlands") +
                            I(RESIDENCE_REGION=="Yorkshire and The Humber"),
                          data = meneFiltered, family = binomial) # saves the logistic regression as an object
nobs(othercoastlogistic) # pulls out the n
sum(othercoastlogistic$y==1) # pulls out n of yeses to DV
summary(othercoastlogistic) # pulls out the p-values
coefothercoast <- as.matrix(exp(coef(othercoastlogistic))) # displays exponents
confintothercoast <- exp(confint.default(othercoastlogistic)) # displays 95% CIs for the exponents
cbind (coefothercoast, confintothercoast) # prints regression table
logisticPseudoR2s(othercoastlogistic) # display psuedo R2 statistics

# Predicting river, lake or canal visit

riverlogistic <- glm(Q5_04 ~ 
                       I(sex=="Female") +
                       I(age_3_cats=="16-34") +
                       I(age_3_cats=="65+") +
                       I(segcombine=="C1") +
                       I(segcombine=="C2") +
                       I(segcombine=="DE") +
                       I(healthmotivecombined=="Yes") +
                       I(relaxmotivecombined=="Yes") +
                       I(socialmotive=="Yes") +
                       I(Visitdate_weekend=="Yes") +
                       I(Season=="Spring") +
                       I(Season=="Summer") +
                       I(Season=="Autumn") +
                       I(year=="2010-2011") +
                       I(year=="2011-2012") +
                       I(year=="2012-2013") +
                       I(year=="2013-2014") +
                       I(year=="2014-2015") +
                       I(year=="2015-2016") +
                       I(RESIDENCE_REGION=="East Midlands") +
                       I(RESIDENCE_REGION=="East of England") +
                       I(RESIDENCE_REGION=="North East") +
                       I(RESIDENCE_REGION=="North West") +
                       I(RESIDENCE_REGION=="South East") +
                       I(RESIDENCE_REGION=="South West") +
                       I(RESIDENCE_REGION=="West Midlands") +
                       I(RESIDENCE_REGION=="Yorkshire and The Humber"),
                     data = meneFiltered, family = binomial) # saves the logistic regression as an object
nobs(riverlogistic) # pulls out the n
sum(riverlogistic$y==1) # pulls out yeses in DV
summary(riverlogistic) # pulls out the p-values
coefriver <- as.matrix (exp(coef(riverlogistic))) # displays exponents
confintriver <- exp(confint.default(riverlogistic)) # displays 95% CIs for the exponents
cbind(coefriver, confintriver) # prints regression table
logisticPseudoR2s(riverlogistic) # display psuedo R2 statistics

# Predicting park visit

parklogistic <- glm(Q5_09 ~ 
                      I(sex=="Female") +
                      I(age_3_cats=="16-34") +
                      I(age_3_cats=="65+") +
                      I(segcombine=="C1") +
                      I(segcombine=="C2") +
                      I(segcombine=="DE") +
                      I(healthmotivecombined=="Yes") +
                      I(relaxmotivecombined=="Yes") +
                      I(socialmotive=="Yes") +
                      I(Visitdate_weekend=="Yes") +
                      I(Season=="Spring") +
                      I(Season=="Summer") +
                      I(Season=="Autumn") +
                      I(year=="2010-2011") +
                      I(year=="2011-2012") +
                      I(year=="2012-2013") +
                      I(year=="2013-2014") +
                      I(year=="2014-2015") +
                      I(year=="2015-2016") +
                      I(RESIDENCE_REGION=="East Midlands") +
                      I(RESIDENCE_REGION=="East of England") +
                      I(RESIDENCE_REGION=="North East") +
                      I(RESIDENCE_REGION=="North West") +
                      I(RESIDENCE_REGION=="South East") +
                      I(RESIDENCE_REGION=="South West") +
                      I(RESIDENCE_REGION=="West Midlands") +
                      I(RESIDENCE_REGION=="Yorkshire and The Humber"),
                    data = meneFiltered, family = binomial) # saves the logistic regression as an object
nobs(parklogistic) # pulls out the n
sum(parklogistic$y==1) # pulls out yeses to DV
summary(parklogistic) # pulls out the p-values
coefpark <- as.matrix(exp(coef(parklogistic))) # displays exponents
confintpark <- exp(confint.default(parklogistic)) # displays 95% CIs for the exponents
cbind(coefpark, confintpark) # prints regression table
logisticPseudoR2s(parklogistic) # display psuedo R2 statistics

# Predicting woods visit

woodslogistic <- glm(Q5_01 ~ 
                       I(sex=="Female") +
                       I(age_3_cats=="16-34") +
                       I(age_3_cats=="65+") +
                       I(segcombine=="C1") +
                       I(segcombine=="C2") +
                       I(segcombine=="DE") +
                       I(healthmotivecombined=="Yes") +
                       I(relaxmotivecombined=="Yes") +
                       I(socialmotive=="Yes") +
                       I(Visitdate_weekend=="Yes") +
                       I(Season=="Spring") +
                       I(Season=="Summer") +
                       I(Season=="Autumn") +
                       I(year=="2010-2011") +
                       I(year=="2011-2012") +
                       I(year=="2012-2013") +
                       I(year=="2013-2014") +
                       I(year=="2014-2015") +
                       I(year=="2015-2016") +
                       I(RESIDENCE_REGION=="East Midlands") +
                       I(RESIDENCE_REGION=="East of England") +
                       I(RESIDENCE_REGION=="North East") +
                       I(RESIDENCE_REGION=="North West") +
                       I(RESIDENCE_REGION=="South East") +
                       I(RESIDENCE_REGION=="South West") +
                       I(RESIDENCE_REGION=="West Midlands") +
                       I(RESIDENCE_REGION=="Yorkshire and The Humber"),
                     data = meneFiltered, family = binomial) # saves the logistic regression as an object
nobs(woodslogistic) # pulls out the n
sum(woodslogistic$y==1) # pulls out yeses for DV
summary(woodslogistic) # pulls out the p-values
coefwoods <- as.matrix(exp(coef(woodslogistic))) # displays exponents
confintwoods <- exp(confint.default(woodslogistic)) # displays 95% CIs for the exponents
cbind(coefwoods, confintwoods) # prints regression table
logisticPseudoR2s(woodslogistic) # display psuedo R2 statistics

#Table4
Table4 <- cbind(coefbeach, confintbeach, coefothercoast, confintothercoast, coefriver, confintriver, coefpark, confintpark, coefwoods, confintwoods)
Table4

# Predicting coastal fishing

fishinglogistic <- glm(coastfish ~ 
                         I(sex=="Female") +
                         I(age_3_cats=="16-34") +
                         I(age_3_cats=="65+") +
                         I(segcombine=="C1") +
                         I(segcombine=="C2") +
                         I(segcombine=="DE") +
                         I(healthmotivecombined=="Yes") +
                         I(relaxmotivecombined=="Yes") +
                         I(socialmotive=="Yes") +
                         I(Visitdate_weekend=="Yes") +
                         I(Season=="Spring") +
                         I(Season=="Summer") +
                         I(Season=="Autumn") +
                         I(year=="2010-2011") +
                         I(year=="2011-2012") +
                         I(year=="2012-2013") +
                         I(year=="2013-2014") +
                         I(year=="2014-2015") +
                         I(year=="2015-2016") +
                         I(RESIDENCE_REGION=="East Midlands") +
                         I(RESIDENCE_REGION=="East of England") +
                         I(RESIDENCE_REGION=="North East") +
                         I(RESIDENCE_REGION=="North West") +
                         I(RESIDENCE_REGION=="South East") +
                         I(RESIDENCE_REGION=="South West") +
                         I(RESIDENCE_REGION=="West Midlands") +
                         I(RESIDENCE_REGION=="Yorkshire and The Humber"),
                       data = meneFiltered, family = binomial) # saves the logistic regression as an object
nobs(fishinglogistic) # pulls out the n
sum(fishinglogistic$y==1) # pulls out yeses to dv
summary(fishinglogistic) # pulls out the p-values
coeffish <- as.matrix(exp(coef(fishinglogistic))) # displays exponents
confintfish <- exp(confint.default(fishinglogistic)) # displays 95% CIs for the exponents
cbind(coeffish, confintfish) # prints regression table
logisticPseudoR2s(fishinglogistic) # display psuedo R2 statistics

# Predicting coastal watersports

wsportslogistic <- glm(coastwatersports ~ 
                         I(sex=="Female") +
                         I(age_3_cats=="16-34") +
                         I(age_3_cats=="65+") +
                         I(segcombine=="C1") +
                         I(segcombine=="C2") +
                         I(segcombine=="DE") +
                         I(healthmotivecombined=="Yes") +
                         I(relaxmotivecombined=="Yes") +
                         I(socialmotive=="Yes") +
                         I(Visitdate_weekend=="Yes") +
                         I(Season=="Spring") +
                         I(Season=="Summer") +
                         I(Season=="Autumn") +
                         I(year=="2010-2011") +
                         I(year=="2011-2012") +
                         I(year=="2012-2013") +
                         I(year=="2013-2014") +
                         I(year=="2014-2015") +
                         I(year=="2015-2016") +
                         I(RESIDENCE_REGION=="East Midlands") +
                         I(RESIDENCE_REGION=="East of England") +
                         I(RESIDENCE_REGION=="North East") +
                         I(RESIDENCE_REGION=="North West") +
                         I(RESIDENCE_REGION=="South East") +
                         I(RESIDENCE_REGION=="South West") +
                         I(RESIDENCE_REGION=="West Midlands") +
                         I(RESIDENCE_REGION=="Yorkshire and The Humber"),
                       data = meneFiltered, family = binomial) # saves the logistic regression as an object
nobs(wsportslogistic) # pulls out the n
sum(wsportslogistic$y==1) # pulls out yeses to dv
summary(wsportslogistic) # pulls out the p-values
coefwsports <- as.matrix(exp(coef(wsportslogistic))) # displays exponents
confintwsports <- exp(confint.default(wsportslogistic)) # displays 95% CIs for the exponents
cbind(coefwsports, confintwsports) # prints regression table
logisticPseudoR2s(wsportslogistic) # display psuedo R2 statistics

# Predicting coastal swimming

swimlogistic <- glm(coastswim ~ 
                      I(sex=="Female") +
                      I(age_3_cats=="16-34") +
                      I(age_3_cats=="65+") +
                      I(segcombine=="C1") +
                      I(segcombine=="C2") +
                      I(segcombine=="DE") +
                      I(healthmotivecombined=="Yes") +
                      I(relaxmotivecombined=="Yes") +
                      I(socialmotive=="Yes") +
                      I(Visitdate_weekend=="Yes") +
                      I(Season=="Spring") +
                      I(Season=="Summer") +
                      I(Season=="Autumn") +
                      I(year=="2010-2011") +
                      I(year=="2011-2012") +
                      I(year=="2012-2013") +
                      I(year=="2013-2014") +
                      I(year=="2014-2015") +
                      I(year=="2015-2016") +
                      I(RESIDENCE_REGION=="East Midlands") +
                      I(RESIDENCE_REGION=="East of England") +
                      I(RESIDENCE_REGION=="North East") +
                      I(RESIDENCE_REGION=="North West") +
                      I(RESIDENCE_REGION=="South East") +
                      I(RESIDENCE_REGION=="South West") +
                      I(RESIDENCE_REGION=="West Midlands") +
                      I(RESIDENCE_REGION=="Yorkshire and The Humber"),
                    data = meneFiltered, family = binomial) # saves the logistic regression as an object
nobs(swimlogistic) # pulls out the n
sum(swimlogistic$y==1) # pulls out yeses for dv
summary(swimlogistic) # pulls out the p-values
coefswim <- as.matrix(exp(coef(swimlogistic))) # displays exponents
confintswim <- exp(confint.default(swimlogistic)) # displays 95% CIs for the exponents
cbind(coefswim, confintswim) # prints regression table
logisticPseudoR2s(swimlogistic) # display psuedo R2 statistics

# Predicting coastal sunbathing/paddling

lobsterlogistic <- glm(coastlobster ~ 
                         I(sex=="Female") +
                         I(age_3_cats=="16-34") +
                         I(age_3_cats=="65+") +
                         I(segcombine=="C1") +
                         I(segcombine=="C2") +
                         I(segcombine=="DE") +
                         I(healthmotivecombined=="Yes") +
                         I(relaxmotivecombined=="Yes") +
                         I(socialmotive=="Yes") +
                         I(Visitdate_weekend=="Yes") +
                         I(Season=="Spring") +
                         I(Season=="Summer") +
                         I(Season=="Autumn") +
                         I(year=="2010-2011") +
                         I(year=="2011-2012") +
                         I(year=="2012-2013") +
                         I(year=="2013-2014") +
                         I(year=="2014-2015") +
                         I(year=="2015-2016") +
                         I(RESIDENCE_REGION=="East Midlands") +
                         I(RESIDENCE_REGION=="East of England") +
                         I(RESIDENCE_REGION=="North East") +
                         I(RESIDENCE_REGION=="North West") +
                         I(RESIDENCE_REGION=="South East") +
                         I(RESIDENCE_REGION=="South West") +
                         I(RESIDENCE_REGION=="West Midlands") +
                         I(RESIDENCE_REGION=="Yorkshire and The Humber"),
                       data = meneFiltered, family = binomial) # saves the logistic regression as an object
nobs(lobsterlogistic) # pulls out the n
sum(lobsterlogistic$y==1) # pulls out yeses for dv
summary(lobsterlogistic) # pulls out the p-values
coeflobster <- as.matrix(exp(coef(lobsterlogistic))) # displays exponents
confintlobster <- exp(confint.default(lobsterlogistic)) # displays 95% CIs for the exponents
cbind(coeflobster, confintlobster) # prints regression table
logisticPseudoR2s(lobsterlogistic) # display psuedo R2 statistics

#Table5
Table5 <- cbind(coeffish, confintfish, coefwsports, confintwsports, coefswim, confintswim, coeflobster, confintlobster)
Table5

# Predicting coastal walking

coastwalklogistic <- glm(coastwalk ~ 
                           I(sex=="Female") +
                           I(age_3_cats=="16-34") +
                           I(age_3_cats=="65+") +
                           I(segcombine=="C1") +
                           I(segcombine=="C2") +
                           I(segcombine=="DE") +
                           I(healthmotivecombined=="Yes") +
                           I(relaxmotivecombined=="Yes") +
                           I(socialmotive=="Yes") +
                           I(Visitdate_weekend=="Yes") +
                           I(Season=="Spring") +
                           I(Season=="Summer") +
                           I(Season=="Autumn") +
                           I(year=="2010-2011") +
                           I(year=="2011-2012") +
                           I(year=="2012-2013") +
                           I(year=="2013-2014") +
                           I(year=="2014-2015") +
                           I(year=="2015-2016") +
                           I(RESIDENCE_REGION=="East Midlands") +
                           I(RESIDENCE_REGION=="East of England") +
                           I(RESIDENCE_REGION=="North East") +
                           I(RESIDENCE_REGION=="North West") +
                           I(RESIDENCE_REGION=="South East") +
                           I(RESIDENCE_REGION=="South West") +
                           I(RESIDENCE_REGION=="West Midlands") +
                           I(RESIDENCE_REGION=="Yorkshire and The Humber"),
                         data = meneFiltered, family = binomial) # saves the logistic regression as an object
nobs(coastwalklogistic) # pulls out the n
sum(coastwalklogistic$y==1) # pulls out yeses for dv
summary(coastwalklogistic) # pulls out the p-values
coefcwalk <- as.matrix(exp(coef(coastwalklogistic))) # displays exponents
confintcwalk <- exp(confint.default(coastwalklogistic)) # displays 95% CIs for the exponents
cbind(coefcwalk, confintcwalk) # prints regression table
logisticPseudoR2s(coastwalklogistic) # display psuedo R2 statistics

# Predicting inland waters walking

riverwalklogistic <- glm(inlandwaterwalk ~ 
                           I(sex=="Female") +
                           I(age_3_cats=="16-34") +
                           I(age_3_cats=="65+") +
                           I(segcombine=="C1") +
                           I(segcombine=="C2") +
                           I(segcombine=="DE") +
                           I(healthmotivecombined=="Yes") +
                           I(relaxmotivecombined=="Yes") +
                           I(socialmotive=="Yes") +
                           I(Visitdate_weekend=="Yes") +
                           I(Season=="Spring") +
                           I(Season=="Summer") +
                           I(Season=="Autumn") +
                           I(year=="2010-2011") +
                           I(year=="2011-2012") +
                           I(year=="2012-2013") +
                           I(year=="2013-2014") +
                           I(year=="2014-2015") +
                           I(year=="2015-2016") +
                           I(RESIDENCE_REGION=="East Midlands") +
                           I(RESIDENCE_REGION=="East of England") +
                           I(RESIDENCE_REGION=="North East") +
                           I(RESIDENCE_REGION=="North West") +
                           I(RESIDENCE_REGION=="South East") +
                           I(RESIDENCE_REGION=="South West") +
                           I(RESIDENCE_REGION=="West Midlands") +
                           I(RESIDENCE_REGION=="Yorkshire and The Humber"),
                         data = meneFiltered, family = binomial) # saves the logistic regression as an object
nobs(riverwalklogistic) # pulls out the n
sum(riverwalklogistic$y==1) # pulls out yeses for dv
summary(riverwalklogistic) # pulls out the p-values
coefrwalk <- as.matrix(exp(coef(riverwalklogistic))) # displays exponents
confintrwalk <- exp(confint.default(riverwalklogistic)) # displays 95% CIs for the exponents
cbind(coefrwalk, confintrwalk)
logisticPseudoR2s(riverwalklogistic) # display psuedo R2 statistics

# Predicting park walking

parkwalklogistic <- glm(parkwalk ~ 
                          I(sex=="Female") +
                          I(age_3_cats=="16-34") +
                          I(age_3_cats=="65+") +
                          I(segcombine=="C1") +
                          I(segcombine=="C2") +
                          I(segcombine=="DE") +
                          I(healthmotivecombined=="Yes") +
                          I(relaxmotivecombined=="Yes") +
                          I(socialmotive=="Yes") +
                          I(Visitdate_weekend=="Yes") +
                          I(Season=="Spring") +
                          I(Season=="Summer") +
                          I(Season=="Autumn") +
                          I(year=="2010-2011") +
                          I(year=="2011-2012") +
                          I(year=="2012-2013") +
                          I(year=="2013-2014") +
                          I(year=="2014-2015") +
                          I(year=="2015-2016") +
                          I(RESIDENCE_REGION=="East Midlands") +
                          I(RESIDENCE_REGION=="East of England") +
                          I(RESIDENCE_REGION=="North East") +
                          I(RESIDENCE_REGION=="North West") +
                          I(RESIDENCE_REGION=="South East") +
                          I(RESIDENCE_REGION=="South West") +
                          I(RESIDENCE_REGION=="West Midlands") +
                          I(RESIDENCE_REGION=="Yorkshire and The Humber"),
                        data = meneFiltered, family = binomial) # saves the logistic regression as an object
nobs(parkwalklogistic) # pulls out the n
sum(parkwalklogistic$y==1) # pulls out yeses for dv
summary(parkwalklogistic) # pulls out the p-values
coefpwalk <- as.matrix(exp(coef(parkwalklogistic))) # displays exponents
confintpwalk <- exp(confint.default(parkwalklogistic)) # displays 95% CIs for the exponents
cbind(coefpwalk, confintpwalk) # prints regression table
logisticPseudoR2s(parkwalklogistic) # display psuedo R2 statistics

# Predicting woodland walking

woodswalklogistic <- glm(woodswalk ~ 
                           I(sex=="Female") +
                           I(age_3_cats=="16-34") +
                           I(age_3_cats=="65+") +
                           I(segcombine=="C1") +
                           I(segcombine=="C2") +
                           I(segcombine=="DE") +
                           I(healthmotivecombined=="Yes") +
                           I(relaxmotivecombined=="Yes") +
                           I(socialmotive=="Yes") +
                           I(Visitdate_weekend=="Yes") +
                           I(Season=="Spring") +
                           I(Season=="Summer") +
                           I(Season=="Autumn") +
                           I(year=="2010-2011") +
                           I(year=="2011-2012") +
                           I(year=="2012-2013") +
                           I(year=="2013-2014") +
                           I(year=="2014-2015") +
                           I(year=="2015-2016") +
                           I(RESIDENCE_REGION=="East Midlands") +
                           I(RESIDENCE_REGION=="East of England") +
                           I(RESIDENCE_REGION=="North East") +
                           I(RESIDENCE_REGION=="North West") +
                           I(RESIDENCE_REGION=="South East") +
                           I(RESIDENCE_REGION=="South West") +
                           I(RESIDENCE_REGION=="West Midlands") +
                           I(RESIDENCE_REGION=="Yorkshire and The Humber"),
                         data = meneFiltered, family = binomial) # saves the logistic regression as an object
nobs(woodswalklogistic) # pulls out the n
sum(woodswalklogistic$y==1) # pulls out yeses for dv
summary(woodswalklogistic) # pulls out the p-values
coefwwalk <- as.matrix(exp(coef(woodswalklogistic))) # displays exponents
confintwwalk <- exp(confint.default(woodswalklogistic)) # displays 95% CIs for the exponents
cbind(coefwwalk, confintwwalk) # prints regression table
logisticPseudoR2s(woodswalklogistic) # display psuedo R2 statistics

#Table6
Table6 <- cbind(coefcwalk, confintcwalk, coefrwalk, confintrwalk, coefpwalk, confintpwalk, coefwwalk, confintwwalk)
Table6

############ END OF REGRESSIONS ############