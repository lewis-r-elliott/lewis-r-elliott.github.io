# Attempted Graph Creation

rm(list=ls()) # Clear workspace

setwd ("U:/20160301_BH/20160803_Data&Papers/20160803_BlueRecWWWWW/20170613_Y1-7MENEData") # Set working directory
dir() # View working directory

graphdata <- read.csv("U:/20160301_BH/20160803_Data&Papers/20160803_BlueRecWWWWW/20170613_Y1-7MENEData/DataforBarGraph.csv")

library(ggplot2) # Loads ggplot2 package
library(scales) # Loads scales package (which comes in handy when labelling axes later - gives commas to millions)

summary(graphdata) # Summarises data

# Sorting out variables

graphdata$Beach.n <- as.numeric(graphdata$Beach.n) # Changes Beach.n to a numeric variable
class(graphdata$Beach.n)
graphdata$Other.coastline.n <- as.numeric(graphdata$Other.coastline.n) # Changes Otjher.coastline.n to a numeric variable
class(graphdata$Other.coastline.n)
graphdata$Beach.SE <- as.numeric(graphdata$Beach.SE) # Changes Beach.SE to a numeric variable
class(graphdata$Beach.SE)
graphdata$Other.coastline.SE <- as.numeric(graphdata$Other.coastline.SE) # Changes Other.coastline.SE to a numeric variable
class(graphdata$Other.coastline.SE)

#Trying to get order right for categories for beach
graphdata$Activtity <- factor(graphdata$Activtity, levels = graphdata$Activtity[order(graphdata$Beach.n, decreasing=TRUE)])

#Creating confidence intervals

graphdata$CIbeach <- 1.96*(graphdata$Beach.SE) # Creates confidence interval
graphdata$CIothercoast <- 1.96*(graphdata$Other.coastline.SE) # Creates confidence interval

#Trying graphs
options(scipen = 999) # gets rid of scientific notation
#Figure 1
plot01 <- ggplot(graphdata, aes(x = Activtity, y = Beach.n)) # creates basic plot
figure01 <- plot01 + # Adds layers to plot
              geom_bar(fill="Dark Grey", stat = "identity") + # Gives bars colour and specifies that a count is desired
              geom_errorbar(ymin=(graphdata$Beach.n -graphdata$CIbeach), ymax=(graphdata$Beach.n + graphdata$CIbeach), size=0.5, width=0.4) + # Specifies the nature of error bars (I went for CIs as a lot clearer)
              theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.3),
                    axis.text.y = element_text(vjust=0.4),
                    axis.title.x = element_text(vjust=1),
                    plot.caption = element_text(family = 'serif', colour='Black', face='italic', size=10, hjust=0)) + # Rotates the x axis labels; hjust=horizontal alignment, vjust=vertical alignment (and y axis)
              scale_x_discrete(name="Activity") + # Renames the x axis
              scale_y_continuous(name="Frequency", limits=c(NA, 80000000), labels=comma) + # renames the y axis, specified min and max limits, and asks labels to include commas (a labels package function)
              labs(caption="
Fig. 1. Annual estimated frequencies of leisure visits to beaches in England taken by the population of England which involve different activities (2009/2010-2015/2016)") 
figure01 # Displays figure
pdf(file = paste(format(Sys.time(), "%Y%m%d"),"Figure 01.pdf"), paper = "special", width = 12, height = 6)
figure01
dev.off() # saves figure as a pdf

#Figure 2
#Have to re-change the order of the Activity factor first
graphdata$Activtity <- factor(graphdata$Activtity, levels = graphdata$Activtity[order(graphdata$Other.coastline.n, decreasing=TRUE)])
plot02 <- ggplot(graphdata, aes(x = Activtity, y = Other.coastline.n)) # creates basic plot
figure02 <- plot02 + # Adds layers to plot
  geom_bar(fill="Dark Grey", stat = "identity") + # Gives bars colour and specifies that a count is desired
  geom_errorbar(ymin=(graphdata$Other.coastline.n - graphdata$CIothercoast), ymax=(graphdata$Other.coastline.n + graphdata$CIothercoast), size=0.5, width=0.4) + # Specifies the nature of error bars (I went for CIs as a lot clearer)
  theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.3),
        axis.text.y = element_text(vjust=0.4),
        axis.title.x = element_text(vjust=1),
        plot.caption = element_text(family = 'serif', colour='Black', face='italic', size=10, hjust=0)) + # Rotates the x axis labels; hjust=horizontal alignment, vjust=vertical alignment (and y axis)
  scale_x_discrete(name="Activity") + # Renames the x axis
  scale_y_continuous(name="Frequency", limits=c(NA, 80000000), labels=comma) + # renames the y axis, specified min and max limits, and asks labels to include commas (a labels package function)
  labs(caption="
Fig. 2. Annual estimated frequencies of leisure visits to other coastline environments in England taken by the population of England which involve different activities (2009/2010-2015/2016)") 
figure02 # Displays figure
pdf(file = paste(format(Sys.time(), "%Y%m%d"),"Figure 02.pdf"), paper = "special", width = 12, height = 6)
figure02
dev.off() # saves figure as a pdf

###END OF SCRIPT###
