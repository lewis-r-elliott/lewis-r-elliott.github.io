# Project: BlueHealth
# Authors: Lewis Elliott, James Grellier, Mathew White, Enrico Scoccimaro, Jo Garrett, Christoph, Lora Fleming
# Title: MENE Weather
# Date created: 20171004
# Date last updated: 20180629

rm(list=ls()) # clear workspace
setwd("U:/20160301_BH/20160803_Data&Papers/20171004_MENE_Weather") # set working directory
dir() # view working directory
mene <- read.csv("weather_original.csv", header=TRUE) # reads in data and labels it "mene"
colnames(mene) # look at variable names

# Load packages
if (!require("pacman")) install.packages("pacman") # Installs the pacman package, which allows for tidy package management
#p_update() # updates packages
  pacman::p_load(car, psych, memisc, broom, forcats, ggplot2, plyr, dplyr, suncalc, lme4, sjstats, visreg, mgcv, rgdal, beepr, gtools)
# Checks if listed packages are already installed, and installs them if not

############################## SELECTING SINGLE ACTIVITY VISITS ##############################

# making a data frame of only single visit-activity people - this should go at the top and all sorting that follows should be "mene2"

# firstly, including only those people who did not report "any other outdoor activity" and "none of the activities in the list"

mene2 <- mene[which(mene$q4_20=="No" & mene$q4_21=="No"),] # excludes around 1,000 cases
mene2$activity <- NA  
mene2$activity[which(mene2$q4_01=="Yes" & (mene2$q4_02=="No" &
                                             mene2$q4_03=="No" &
                                             mene2$q4_04=="No" &
                                             mene2$q4_05=="No" &
                                             mene2$q4_06=="No" &
                                             mene2$q4_07=="No" &
                                             mene2$q4_08=="No" &
                                             mene2$q4_09=="No" &
                                             mene2$q4_10=="No" &
                                             mene2$q4_11=="No" &
                                             mene2$q4_12=="No" &
                                             mene2$q4_13=="No" &
                                             mene2$q4_14=="No" &
                                             mene2$q4_15=="No" &
                                             mene2$q4_16=="No" &
                                             mene2$q4_17=="No" &
                                             mene2$q4_18=="No" &
                                             mene2$q4_19=="No"))] <- "eating or drinking out"
mene2$activity[which(mene2$q4_02=="Yes" & (mene2$q4_01=="No" &
                                             mene2$q4_03=="No" &
                                             mene2$q4_04=="No" &
                                             mene2$q4_05=="No" &
                                             mene2$q4_06=="No" &
                                             mene2$q4_07=="No" &
                                             mene2$q4_08=="No" &
                                             mene2$q4_09=="No" &
                                             mene2$q4_10=="No" &
                                             mene2$q4_11=="No" &
                                             mene2$q4_12=="No" &
                                             mene2$q4_13=="No" &
                                             mene2$q4_14=="No" &
                                             mene2$q4_15=="No" &
                                             mene2$q4_16=="No" &
                                             mene2$q4_17=="No" &
                                             mene2$q4_18=="No" &
                                             mene2$q4_19=="No"))] <- "fieldsports"
mene2$activity[which(mene2$q4_03=="Yes" & (mene2$q4_01=="No" &
                                             mene2$q4_02=="No" &
                                             mene2$q4_04=="No" &
                                             mene2$q4_05=="No" &
                                             mene2$q4_06=="No" &
                                             mene2$q4_07=="No" &
                                             mene2$q4_08=="No" &
                                             mene2$q4_09=="No" &
                                             mene2$q4_10=="No" &
                                             mene2$q4_11=="No" &
                                             mene2$q4_12=="No" &
                                             mene2$q4_13=="No" &
                                             mene2$q4_14=="No" &
                                             mene2$q4_15=="No" &
                                             mene2$q4_16=="No" &
                                             mene2$q4_17=="No" &
                                             mene2$q4_18=="No" &
                                             mene2$q4_19=="No"))] <- "fishing"
mene2$activity[which(mene2$q4_04=="Yes" & (mene2$q4_01=="No" &
                                             mene2$q4_02=="No" &
                                             mene2$q4_03=="No" &
                                             mene2$q4_05=="No" &
                                             mene2$q4_06=="No" &
                                             mene2$q4_07=="No" &
                                             mene2$q4_08=="No" &
                                             mene2$q4_09=="No" &
                                             mene2$q4_10=="No" &
                                             mene2$q4_11=="No" &
                                             mene2$q4_12=="No" &
                                             mene2$q4_13=="No" &
                                             mene2$q4_14=="No" &
                                             mene2$q4_15=="No" &
                                             mene2$q4_16=="No" &
                                             mene2$q4_17=="No" &
                                             mene2$q4_18=="No" &
                                             mene2$q4_19=="No"))] <- "horse riding"
mene2$activity[which(mene2$q4_05=="Yes" & (mene2$q4_01=="No" &
                                             mene2$q4_02=="No" &
                                             mene2$q4_03=="No" &
                                             mene2$q4_04=="No" &
                                             mene2$q4_06=="No" &
                                             mene2$q4_07=="No" &
                                             mene2$q4_08=="No" &
                                             mene2$q4_09=="No" &
                                             mene2$q4_10=="No" &
                                             mene2$q4_11=="No" &
                                             mene2$q4_12=="No" &
                                             mene2$q4_13=="No" &
                                             mene2$q4_14=="No" &
                                             mene2$q4_15=="No" &
                                             mene2$q4_16=="No" &
                                             mene2$q4_17=="No" &
                                             mene2$q4_18=="No" &
                                             mene2$q4_19=="No"))] <- "off-road cycling or mountain biking"
mene2$activity[which(mene2$q4_06=="Yes" & (mene2$q4_01=="No" &
                                             mene2$q4_02=="No" &
                                             mene2$q4_03=="No" &
                                             mene2$q4_04=="No" &
                                             mene2$q4_05=="No" &
                                             mene2$q4_07=="No" &
                                             mene2$q4_08=="No" &
                                             mene2$q4_09=="No" &
                                             mene2$q4_10=="No" &
                                             mene2$q4_11=="No" &
                                             mene2$q4_12=="No" &
                                             mene2$q4_13=="No" &
                                             mene2$q4_14=="No" &
                                             mene2$q4_15=="No" &
                                             mene2$q4_16=="No" &
                                             mene2$q4_17=="No" &
                                             mene2$q4_18=="No" &
                                             mene2$q4_19=="No"))] <- "off-road driving or motorcycling"
mene2$activity[which(mene2$q4_07=="Yes" & (mene2$q4_01=="No" &
                                             mene2$q4_02=="No" &
                                             mene2$q4_03=="No" &
                                             mene2$q4_04=="No" &
                                             mene2$q4_05=="No" &
                                             mene2$q4_06=="No" &
                                             mene2$q4_08=="No" &
                                             mene2$q4_09=="No" &
                                             mene2$q4_10=="No" &
                                             mene2$q4_11=="No" &
                                             mene2$q4_12=="No" &
                                             mene2$q4_13=="No" &
                                             mene2$q4_14=="No" &
                                             mene2$q4_15=="No" &
                                             mene2$q4_16=="No" &
                                             mene2$q4_17=="No" &
                                             mene2$q4_18=="No" &
                                             mene2$q4_19=="No"))] <- "picnicking"
mene2$activity[which(mene2$q4_08=="Yes" & (mene2$q4_01=="No" &
                                             mene2$q4_02=="No" &
                                             mene2$q4_03=="No" &
                                             mene2$q4_04=="No" &
                                             mene2$q4_05=="No" &
                                             mene2$q4_06=="No" &
                                             mene2$q4_07=="No" &
                                             mene2$q4_09=="No" &
                                             mene2$q4_10=="No" &
                                             mene2$q4_11=="No" &
                                             mene2$q4_12=="No" &
                                             mene2$q4_13=="No" &
                                             mene2$q4_14=="No" &
                                             mene2$q4_15=="No" &
                                             mene2$q4_16=="No" &
                                             mene2$q4_17=="No" &
                                             mene2$q4_18=="No" &
                                             mene2$q4_19=="No"))] <- "playing with children"
mene2$activity[which(mene2$q4_09=="Yes" & (mene2$q4_01=="No" &
                                             mene2$q4_02=="No" &
                                             mene2$q4_03=="No" &
                                             mene2$q4_04=="No" &
                                             mene2$q4_05=="No" &
                                             mene2$q4_06=="No" &
                                             mene2$q4_07=="No" &
                                             mene2$q4_08=="No" &
                                             mene2$q4_10=="No" &
                                             mene2$q4_11=="No" &
                                             mene2$q4_12=="No" &
                                             mene2$q4_13=="No" &
                                             mene2$q4_14=="No" &
                                             mene2$q4_15=="No" &
                                             mene2$q4_16=="No" &
                                             mene2$q4_17=="No" &
                                             mene2$q4_18=="No" &
                                             mene2$q4_19=="No"))] <- "road cycling"
mene2$activity[which(mene2$q4_10=="Yes" & (mene2$q4_01=="No" &
                                             mene2$q4_02=="No" &
                                             mene2$q4_03=="No" &
                                             mene2$q4_04=="No" &
                                             mene2$q4_05=="No" &
                                             mene2$q4_06=="No" &
                                             mene2$q4_07=="No" &
                                             mene2$q4_08=="No" &
                                             mene2$q4_09=="No" &
                                             mene2$q4_11=="No" &
                                             mene2$q4_12=="No" &
                                             mene2$q4_13=="No" &
                                             mene2$q4_14=="No" &
                                             mene2$q4_15=="No" &
                                             mene2$q4_16=="No" &
                                             mene2$q4_17=="No" &
                                             mene2$q4_18=="No" &
                                             mene2$q4_19=="No"))] <- "running"
mene2$activity[which(mene2$q4_11=="Yes" & (mene2$q4_01=="No" &
                                             mene2$q4_02=="No" &
                                             mene2$q4_03=="No" &
                                             mene2$q4_04=="No" &
                                             mene2$q4_05=="No" &
                                             mene2$q4_06=="No" &
                                             mene2$q4_07=="No" &
                                             mene2$q4_08=="No" &
                                             mene2$q4_09=="No" &
                                             mene2$q4_10=="No" &
                                             mene2$q4_12=="No" &
                                             mene2$q4_13=="No" &
                                             mene2$q4_14=="No" &
                                             mene2$q4_15=="No" &
                                             mene2$q4_16=="No" &
                                             mene2$q4_17=="No" &
                                             mene2$q4_18=="No" &
                                             mene2$q4_19=="No"))] <- "appreciating scenery from a car"
mene2$activity[which(mene2$q4_12=="Yes" & (mene2$q4_01=="No" &
                                             mene2$q4_02=="No" &
                                             mene2$q4_03=="No" &
                                             mene2$q4_04=="No" &
                                             mene2$q4_05=="No" &
                                             mene2$q4_06=="No" &
                                             mene2$q4_07=="No" &
                                             mene2$q4_08=="No" &
                                             mene2$q4_09=="No" &
                                             mene2$q4_10=="No" &
                                             mene2$q4_11=="No" &
                                             mene2$q4_13=="No" &
                                             mene2$q4_14=="No" &
                                             mene2$q4_15=="No" &
                                             mene2$q4_16=="No" &
                                             mene2$q4_17=="No" &
                                             mene2$q4_18=="No" &
                                             mene2$q4_19=="No"))] <- "swimming outdoors"
mene2$activity[which(mene2$q4_13=="Yes" & (mene2$q4_01=="No" &
                                             mene2$q4_02=="No" &
                                             mene2$q4_03=="No" &
                                             mene2$q4_04=="No" &
                                             mene2$q4_05=="No" &
                                             mene2$q4_06=="No" &
                                             mene2$q4_07=="No" &
                                             mene2$q4_08=="No" &
                                             mene2$q4_09=="No" &
                                             mene2$q4_10=="No" &
                                             mene2$q4_11=="No" &
                                             mene2$q4_12=="No" &
                                             mene2$q4_14=="No" &
                                             mene2$q4_15=="No" &
                                             mene2$q4_16=="No" &
                                             mene2$q4_17=="No" &
                                             mene2$q4_18=="No" &
                                             mene2$q4_19=="No"))] <- "beach, sunbathing, or paddling"
mene2$activity[which(mene2$q4_14=="Yes" & (mene2$q4_01=="No" &
                                             mene2$q4_02=="No" &
                                             mene2$q4_03=="No" &
                                             mene2$q4_04=="No" &
                                             mene2$q4_05=="No" &
                                             mene2$q4_06=="No" &
                                             mene2$q4_07=="No" &
                                             mene2$q4_08=="No" &
                                             mene2$q4_09=="No" &
                                             mene2$q4_10=="No" &
                                             mene2$q4_11=="No" &
                                             mene2$q4_12=="No" &
                                             mene2$q4_13=="No" &
                                             mene2$q4_15=="No" &
                                             mene2$q4_16=="No" &
                                             mene2$q4_17=="No" &
                                             mene2$q4_18=="No" &
                                             mene2$q4_19=="No"))] <- "visiting an attraction"
mene2$activity[which(mene2$q4_15=="Yes" & (mene2$q4_01=="No" &
                                             mene2$q4_02=="No" &
                                             mene2$q4_03=="No" &
                                             mene2$q4_04=="No" &
                                             mene2$q4_05=="No" &
                                             mene2$q4_06=="No" &
                                             mene2$q4_07=="No" &
                                             mene2$q4_08=="No" &
                                             mene2$q4_09=="No" &
                                             mene2$q4_10=="No" &
                                             mene2$q4_11=="No" &
                                             mene2$q4_12=="No" &
                                             mene2$q4_13=="No" &
                                             mene2$q4_14=="No" &
                                             mene2$q4_16=="No" &
                                             mene2$q4_17=="No" &
                                             mene2$q4_18=="No" &
                                             mene2$q4_19=="No"))] <- "walking without a dog"
mene2$activity[which(mene2$q4_16=="Yes" & (mene2$q4_01=="No" &
                                             mene2$q4_02=="No" &
                                             mene2$q4_03=="No" &
                                             mene2$q4_04=="No" &
                                             mene2$q4_05=="No" &
                                             mene2$q4_06=="No" &
                                             mene2$q4_07=="No" &
                                             mene2$q4_08=="No" &
                                             mene2$q4_09=="No" &
                                             mene2$q4_10=="No" &
                                             mene2$q4_11=="No" &
                                             mene2$q4_12=="No" &
                                             mene2$q4_13=="No" &
                                             mene2$q4_14=="No" &
                                             mene2$q4_15=="No" &
                                             mene2$q4_17=="No" &
                                             mene2$q4_18=="No" &
                                             mene2$q4_19=="No"))] <- "walking with a dog"
mene2$activity[which(mene2$q4_17=="Yes" & (mene2$q4_01=="No" &
                                             mene2$q4_02=="No" &
                                             mene2$q4_03=="No" &
                                             mene2$q4_04=="No" &
                                             mene2$q4_05=="No" &
                                             mene2$q4_06=="No" &
                                             mene2$q4_07=="No" &
                                             mene2$q4_08=="No" &
                                             mene2$q4_09=="No" &
                                             mene2$q4_10=="No" &
                                             mene2$q4_11=="No" &
                                             mene2$q4_12=="No" &
                                             mene2$q4_13=="No" &
                                             mene2$q4_14=="No" &
                                             mene2$q4_15=="No" &
                                             mene2$q4_16=="No" &
                                             mene2$q4_18=="No" &
                                             mene2$q4_19=="No"))] <- "watersports"
mene2$activity[which(mene2$q4_18=="Yes" & (mene2$q4_01=="No" &
                                             mene2$q4_02=="No" &
                                             mene2$q4_03=="No" &
                                             mene2$q4_04=="No" &
                                             mene2$q4_05=="No" &
                                             mene2$q4_06=="No" &
                                             mene2$q4_07=="No" &
                                             mene2$q4_08=="No" &
                                             mene2$q4_09=="No" &
                                             mene2$q4_10=="No" &
                                             mene2$q4_11=="No" &
                                             mene2$q4_12=="No" &
                                             mene2$q4_13=="No" &
                                             mene2$q4_14=="No" &
                                             mene2$q4_15=="No" &
                                             mene2$q4_16=="No" &
                                             mene2$q4_17=="No" &
                                             mene2$q4_19=="No"))] <- "wildlife watching"
mene2$activity[which(mene2$q4_19=="Yes" & (mene2$q4_01=="No" &
                                             mene2$q4_02=="No" &
                                             mene2$q4_03=="No" &
                                             mene2$q4_04=="No" &
                                             mene2$q4_05=="No" &
                                             mene2$q4_06=="No" &
                                             mene2$q4_07=="No" &
                                             mene2$q4_08=="No" &
                                             mene2$q4_09=="No" &
                                             mene2$q4_10=="No" &
                                             mene2$q4_11=="No" &
                                             mene2$q4_12=="No" &
                                             mene2$q4_13=="No" &
                                             mene2$q4_14=="No" &
                                             mene2$q4_15=="No" &
                                             mene2$q4_16=="No" &
                                             mene2$q4_17=="No" &
                                             mene2$q4_18=="No"))] <- "informal games and sport"
mene2$activity <- factor(mene2$activity) # changing this to a factor
summary(mene2$activity) # summarising this new single-activity variable
mene3 <- mene2[which(!is.na(mene2$activity)),] # creating a new dataframe of just single-activity visits

##############################METS##############################

# appending MET rates to activities

MET_rates <- as.data.frame(levels(mene3$activity)) # taking the levels of 'activity' and turning them into a data frame
names(MET_rates)[1] <- "activity" # renaming the first variable in this new data frame "activity" for merging purposes
MET_rates$METs <- c(1.30,1.90,1.75,6.39,3.50,5.50,4.43,8.50,4.00,1.75,3.58,7.50,7.00,6.00,3.50,3.00,3.50,5.78,2.50) # MET rates from Elliott et al., 2015
mene3 <- join(mene3,MET_rates,by='activity') # nice lookup table join thanks to plyr
summary(mene3$METs)

# MET minutes - our key DV

mene3$METmins <- NA
mene3$METmins <- mene3$Duration_combined*mene3$METs
mene3$METmins[which(mene3$Duration_combined==0)] <- NA
hist(mene3$METmins, breaks=100)
summary(mene3$METmins)
mene3$METminsLOG <- log(mene3$METmins) # for sensitivity analyses, we will aslo use log transformed met minutes
hist(mene3$METminsLOG, breaks=100)
summary(mene3$METminsLOG)

##############################LATS AND LONGS##############################

# changing eastings and northings to latitudes and longitudes

wgs84 <- "+init=epsg:4326"
bng <- '+proj=tmerc +lat_0=49 +lon_0=-2 +k=0.9996012717 +x_0=400000 +y_0=-100000 
+ellps=airy +datum=OSGB36 +units=m +no_defs'

ConvertCoordinates <- function(easting,northing) {
  out = cbind(easting,northing)
  mask = !is.na(easting)
  sp <-  sp::spTransform(sp::SpatialPoints(list(easting[mask],northing[mask]),proj4string=sp::CRS(bng)),sp::CRS(wgs84))
  out[mask,]=sp@coords
  out
} # Got all of this from a most excellent blog

latlongs <- data.frame(ConvertCoordinates(mene3$DESTINATION_EASTING, mene3$DESTINATION_NORTHING)) # making a dataframe of lats and longs
mene3 <- cbind(mene3, latlongs) # merging them to mene3
mene3$lon <- mene3$easting # changing variable name to work in cartography
mene3$lat <- mene3$northing # changing variable name to work in cartography

##############################MISSING VISIT DATES##############################

# filling in the 24 missing visit dates (no idea why missing, but perfectly computable)

mene3$Interviewdate_date <- as.Date(mene3$Interviewdate, format = "%m/%d/%Y") # changing interview date to date format
summary(mene3$Interviewdate_date)
summary(mene3$tripnum)
mene3$tripnum_new <- fct_collapse(mene3$tripnum,
                                  yesterday=c("01. Yesterday(Day 1) First","02. Yesterday(Day 1) Second","03. Yesterday(Day 1) Third"),
                                  '2 days ago'=c("04. The day before Yesterday(Day 2) First","05. The day before Yesterday(Day 2) Second","06. The day before Yesterday(Day 2) Third"),
                                  '3 days ago'=c("07. Variable Day 3 First","08. Variable Day 3 Second","09. Variable Day 3 Third"),
                                  '4 days ago'=c("10. Variable Day 4 First","11. Variable Day 4 Second","12. Variable Day 4 Third"),
                                  '5 days ago'=c("13. Variable Day 5 First","14. Variable Day 5 Second","15. Variable Day 5 Third"),
                                  '6 days ago'=c("16. Variable Day 6 First","17. Variable Day 6 Second","18. Variable Day 6 Third"),
                                  '7 days ago'=c("19. Variable Day 7 First","20. Variable Day 7 Second","21. Variable Day 7 Third"))
fct_count(mene3$tripnum_new)
mene3$tripnum_new <- fct_recode(mene3$tripnum_new,
                                '1' = "yesterday",
                                '2' = "2 days ago",
                                '3' = "3 days ago",
                                '4' = "4 days ago",
                                '5' = "5 days ago",
                                '6' = "6 days ago",
                                '7' = "7 days ago")
fct_count(mene3$tripnum_new)
mene3$tripnum_new <- as.numeric(mene3$tripnum_new)
mene3$Visitdate_date <- as.Date(NA)
mene3$Visitdate_date[which(is.na(mene3$Visitdate_date))] <- mene3$Interviewdate_date - mene3$tripnum_new
summary(mene3$Visitdate_date) # works

##############################WEATHER VARIABLES##############################

# sorting weather variables

# daily maximum air temperature

hist(mene3$DAY_MAX_TEMP, breaks=100) # normally distributed
describe(mene3$DAY_MAX_TEMP) # negative temperatures necessitate conversioin to fahrenheit/kelvin for quadratic terms
mene3$DAY_MAX_TEMP_F <- mene3$DAY_MAX_TEMP * 1.8 + 32 # converting to fahrenheit
mene3$DAY_MAX_TEMP_K <- mene3$DAY_MAX_TEMP + 273.15 # converting to kelvin
describe(mene3$DAY_MAX_TEMP_F) # all temperatures are now positive (fahrenheit)
describe(mene3$DAY_MAX_TEMP_K) # all temperatures are now positive (kelvin)

# daily maximum wind speed

hist(mene3$DAY_MAX_WINDSPEED, breaks=100) # a bit skewed but mostly normally distributed
describe(mene3$DAY_MAX_WINDSPEED)

# daylight hours

describe(mene3$DAY_HOURS) # integer data
hist(mene3$DAY_HOURS) # pattern whereby less available data on days with odd numbers of daylight hours
summary(as.factor(mene3$DAY_HOURS)) # potentially necessitates sensible bins

# sourcing more accurate sunrise and sunset times
mene3$date <- mene3$Visitdate_date # changing variable name to suit use in suncalc package
mene3 <- getSunlightTimes(data = mene3, keep=c("dawn","dusk"), tz="UTC") # uses suncalc to get sunrise and sunset times and appends them to mene3
mene3$day_length <- mene3$dusk - mene3$dawn # calculating a measure of day length
mene3$day_length <- as.numeric(mene3$day_length) # changing to numeric class
head(mene3) # it has worked
hist(mene3$day_length,breaks=100) # distribution is whack - christmas/winter holiday effect?
summary(as.factor(mene3$Visitdate_date)) # checks out: 5th of January 2013 most popular day (unseasonably warm apparently as was the 2nd of Jan - the 8th most visited). June solstice time also very popular.

# rainfall

hist(mene3$DAY_MAX_RAIN) # lots of zeros so categorising into no rain and some rain

mene3$rain_2cats <- NA
mene3$rain_2cats[which(mene3$DAY_MAX_RAIN==0)] <- "no rain"
mene3$rain_2cats[which(mene3$DAY_MAX_RAIN>0)] <- "some rain"
mene3$rain_2cats <- factor(mene3$rain_2cats)
summary(mene3$rain_2cats)

mene3$rain_3cats <- NA
mene3$rain_3cats[which(mene3$DAY_MAX_RAIN==0)] <- "no rain"
mene3$rain_3cats[which(mene3$DAY_MAX_RAIN>0 & mene3$DAY_MAX_RAIN<=0.5)] <- "light rain"
mene3$rain_3cats[which(mene3$DAY_MAX_RAIN>0.5)] <- "moderate/heavy rain"
mene3$rain_3cats <- factor(mene3$rain_3cats, level=c("no rain","light rain","moderate/heavy rain"))
fct_count(mene3$rain_3cats)

##############################COVARIATES##############################

# type of place visited

mene3$place4 <- NA
mene3$place4[which(mene3$q5_14=="Yes" | mene3$q5_15=="Yes" & 
                     mene3$q5_01=="No" &
                     mene3$q5_02=="No" &
                     mene3$q5_03=="No" &
                     mene3$q5_04=="No" &
                     mene3$q5_05=="No" &
                     mene3$q5_06=="No" &
                     mene3$q5_07=="No" &
                     mene3$q5_08=="No" &
                     mene3$q5_09=="No" &
                     mene3$q5_10=="No" &
                     mene3$q5_11=="No" &
                     mene3$q5_12=="No" &
                     mene3$q5_13=="No" &
                     mene3$q5_16=="No" &
                     mene3$q5_17=="No")] <- "coast"
mene3$place4[which(mene3$q5_04=="Yes" & 
                     mene3$q5_01=="No" &
                     mene3$q5_02=="No" &
                     mene3$q5_03=="No" &
                     mene3$q5_05=="No" &
                     mene3$q5_06=="No" &
                     mene3$q5_07=="No" &
                     mene3$q5_08=="No" &
                     mene3$q5_09=="No" &
                     mene3$q5_10=="No" &
                     mene3$q5_11=="No" &
                     mene3$q5_12=="No" &
                     mene3$q5_13=="No" &
                     mene3$q5_14=="No" &
                     mene3$q5_15=="No" &
                     mene3$q5_16=="No" &
                     mene3$q5_17=="No")] <- "river"
mene3$place4[which(mene3$q5_09=="Yes" & 
                     mene3$q5_01=="No" &
                     mene3$q5_02=="No" &
                     mene3$q5_03=="No" &
                     mene3$q5_04=="No" &
                     mene3$q5_05=="No" &
                     mene3$q5_06=="No" &
                     mene3$q5_07=="No" &
                     mene3$q5_08=="No" &
                     mene3$q5_10=="No" &
                     mene3$q5_11=="No" &
                     mene3$q5_12=="No" &
                     mene3$q5_13=="No" &
                     mene3$q5_14=="No" &
                     mene3$q5_15=="No" &
                     mene3$q5_16=="No" &
                     mene3$q5_17=="No")] <- "park"
mene3$place4[which(mene3$q5_01=="Yes" & 
                     mene3$q5_02=="No" &
                     mene3$q5_03=="No" &
                     mene3$q5_04=="No" &
                     mene3$q5_05=="No" &
                     mene3$q5_06=="No" &
                     mene3$q5_07=="No" &
                     mene3$q5_08=="No" &
                     mene3$q5_09=="No" &
                     mene3$q5_10=="No" &
                     mene3$q5_11=="No" &
                     mene3$q5_12=="No" &
                     mene3$q5_13=="No" &
                     mene3$q5_14=="No" &
                     mene3$q5_15=="No" &
                     mene3$q5_16=="No" &
                     mene3$q5_17=="No")] <- "woodland"

mene3$place4 <- factor(mene3$place4, levels=c("park","woodland","river","coast"))

summary(mene3$place4)

# collapsing demographic covariates

# sex

summary(mene3$sex)
contrasts(mene3$sex) # looks fine as is

# age

mene3$age_cats <- NA
mene3$age_cats[which(mene3$age=="16-24"|mene3$age=="25-34")] <- "16-34"
mene3$age_cats[which(mene3$age=="35-44"|mene3$age=="45-54"|mene3$age=="55-64")] <- "35-64"
mene3$age_cats[which(mene3$age=="65+")] <- "65 and over"
mene3$age_cats <- factor(mene3$age_cats)
summary(mene3$age_cats) # age in 3 bins
contrasts(mene3$age_cats)

# ses

summary(mene3$SEGcombine) # looks fine as is

# ethnicity

as.matrix(summary(mene3$ethnicity))
mene3$ethnic_cats <- fct_collapse(mene3$ethnicity,
                                  'All other ethnicities'=c("African","Any other","Any other Asian backgrund","Any other Black background","Any other mixed background",
                                                            "Any other white background","Bangladeshi","Caribbean","Chinese","Indian","Pakistani","Refused",
                                                            "White & Asian","White & Black African","White & Black Carib bean","White Irish"),
                                  'White British' = "White British")
fct_count(mene3$ethnic_cats) # ethnicity in two categories

# disability

as.matrix(summary(mene3$disability)) # fine as is

# martial status

as.matrix(summary(mene3$marital)) # 3 NA's
mene3$marital <- fct_explicit_na(mene3$marital, na_level = "(Missing)")
as.matrix(summary(mene3$marital))
mene3$marital_cats <- fct_collapse(mene3$marital,
                                   Married="Married",
                                   'Not married' = c("Sep/Wid/div","Single","(Missing)"))
mene3$marital_cats <- fct_relevel(mene3$marital_cats, "Not married", "Married")
fct_count(mene3$marital_cats) # 2 marriage categories

# work status

fct_count(mene3$workstat)
mene3$work <- fct_collapse(mene3$workstat,
                           'Full-time'="F/T 30+ hrs",
                           'Part-time'=c("P/T <8  hrs","P/T 8-29 hrs"),
                           'In education'=c("At school","F/T hghr educ"),
                           'Retired'="Retired",
                           'Unemployed/Not working'=c("Unemployed","Not seeking"))
mene3$work <- fct_relevel(mene3$work, "Unemployed/Not working","Full-time","Part-time","In education","Retired")
fct_count(mene3$work)

# children in household

fct_count(mene3$children_in_hh)
mene3$children_in_hh <- fct_relevel(mene3$children_in_hh, "None","Any")
fct_count(mene3$children_in_hh)

# visits-based covriates

# weekday/weekend 

mene3$visitday <- as.factor(weekdays(mene3$Visitdate_date))
summary(mene3$visitday)

mene3$wkday_wkend <- fct_collapse(mene3$visitday,
                                  Weekday=c("Monday","Tuesday","Wednesday","Thursday","Friday"),
                                  Weekend=c("Saturday","Sunday"))
fct_count(mene3$wkday_wkend)

# defining a local visit versus further afield variable

# first, sorting out start point, travel distance, and mode

# visit start point

fct_count(mene3$q9)
mene3$start_point <- fct_collapse(mene3$q9,
                                  Home="Your home",
                                  Elsewhere=c("Holiday accommodation","Someone else's home","Somewhere else","Work"))
mene3$start_point <- fct_relevel(mene3$start_point, "Elsewhere", "Home")
fct_count(mene3$start_point)

# visit travel distance (soc sci med paper)

fct_count(mene3$q8)
mene3$distance <- fct_collapse(mene3$q8,
                               'Less than 1 mile'="(0.5)  Less than 1 mile",
                               '1 to 5 miles'=c("(1.5)  1 or 2 miles","(4.0)  3 to 5 miles"),
                               '6 to 20 miles'=c("(8.0)  6 to 10 miles","(15.5) 11 to 20 miles"),
                               'Over 20 miles'=c("(30.5) 21 to 40 miles","(50.5) 41 to 60 miles","(70.5) 61 to 80 miles","(90.5) 81 to 100 miles","(120)  More than 100 miles"))
mene3$distance <- fct_relevel(mene3$distance, "Less than 1 mile","1 to 5 miles","6 to 20 miles","Over 20 miles")
fct_count(mene3$distance)

# visit travel mode (soc sci med paper)

fct_count(mene3$q11)
mene3$mode <- fct_collapse(mene3$q11,
                           'Personal motorised transport'=c("Car/van","Motorcycle/ scooter"),
                           'Public transport'=c("Public bus or coach (scheduled service)","Train (includes tube/underground)"),
                           'On foot (including wheelchair use)'=c("On foot/ walking","Wheelchair/mobility scooter"),
                           'By bicycle'="Bicycle/ mountain bike",
                           'Other'=c("Boat (sail or motor)","Coach trip/ private coach","On horseback","Other","Taxi"))
mene3$mode <- fct_relevel(mene3$mode, "On foot (including wheelchair use)","Personal motorised transport","Public transport","By bicycle","Other")
fct_count(mene3$mode) # this may be discounted in the variable due to possibility of including active travel in MET minutes estimates

# defining the new local visit versus further afield variable

mene3$local <- NA
mene3$local[which(mene3$start_point=="Home" & mene3$distance=="Less than 1 mile")] <- "Local visit"
mene3$local[which(is.na(mene3$local))] <- "Further afield"
mene3$local <- fct_relevel(mene3$local, "Local visit","Further afield")
fct_count(mene3$local)

# urban rural classification

fct_count(mene3$DESTINATION_RURALURBAN)
mene3$dest_ruralurban <- fct_collapse(mene3$DESTINATION_RURALURBAN,
                                      'Rural'=c("HAMLET  ISOLATED DWELLING - SPARSE","HAMLET  ISOLATED DWELLINGS - LESS SPARSE","TOWN  FRINGE - LESS SPARSE","TOWN  FRINGE - SPARSE",
                                                "VILLAGE - LESS SPARSE","VILLAGE - SPARSE"),
                                      'Urban'=c("URBAN >10K - LESS SPARSE","URBAN >10K - SPARSE"))
mene3$dest_ruralurban[which(mene3$dest_ruralurban==0)] <- NA
mene3$dest_ruralurban <- fct_drop(mene3$dest_ruralurban)
fct_count(mene3$dest_ruralurban)
table(mene3$dest_ruralurban, mene3$place4) # decent amount of coasts, rivers, parks and woodlands in both urban and rural areas

##############################REDOING DATES##############################

# recoding month/year  
mene3$my <- format(mene3$Visitdate_date, "%m-%Y")
mene3$my <- factor(mene3$my)
fct_count(mene3$my)
mene3$my <- fct_recode(mene3$my,
                       'Feb 2009'="02-2009",
                       'Mar 2009'="03-2009",
                       'Apr 2009'="04-2009",
                       'May 2009'="05-2009",
                       'Jun 2009'="06-2009",
                       'Jul 2009'="07-2009",
                       'Aug 2009'="08-2009",
                       'Sep 2009'="09-2009",
                       'Oct 2009'="10-2009",
                       'Nov 2009'="11-2009",
                       'Dec 2009'="12-2009",
                       'Jan 2010'="01-2010",
                       'Feb 2010'="02-2010",
                       'Mar 2010'="03-2010",
                       'Apr 2010'="04-2010",
                       'May 2010'="05-2010",
                       'Jun 2010'="06-2010",
                       'Jul 2010'="07-2010",
                       'Aug 2010'="08-2010",
                       'Sep 2010'="09-2010",
                       'Oct 2010'="10-2010",
                       'Nov 2010'="11-2010",
                       'Dec 2010'="12-2010",
                       'Jan 2011'="01-2011",
                       'Feb 2011'="02-2011",
                       'Mar 2011'="03-2011",
                       'Apr 2011'="04-2011",
                       'May 2011'="05-2011",
                       'Jun 2011'="06-2011",
                       'Jul 2011'="07-2011",
                       'Aug 2011'="08-2011",
                       'Sep 2011'="09-2011",
                       'Oct 2011'="10-2011",
                       'Nov 2011'="11-2011",
                       'Dec 2011'="12-2011",
                       'Jan 2012'="01-2012",
                       'Feb 2012'="02-2012",
                       'Mar 2012'="03-2012",
                       'Apr 2012'="04-2012",
                       'May 2012'="05-2012",
                       'Jun 2012'="06-2012",
                       'Jul 2012'="07-2012",
                       'Aug 2012'="08-2012",
                       'Sep 2012'="09-2012",
                       'Oct 2012'="10-2012",
                       'Nov 2012'="11-2012",
                       'Dec 2012'="12-2012",
                       'Jan 2013'="01-2013",
                       'Feb 2013'="02-2013",
                       'Mar 2013'="03-2013")
mene3$my <- fct_relevel(mene3$my, "Feb 2009","Mar 2009","Apr 2009","May 2009","Jun 2009","Jul 2009","Aug 2009","Sep 2009","Oct 2009","Nov 2009","Dec 2009",
                        "Jan 2010","Feb 2010","Mar 2010","Apr 2010","May 2010","Jun 2010","Jul 2010","Aug 2010","Sep 2010","Oct 2010","Nov 2010","Dec 2010",
                        "Jan 2011","Feb 2011","Mar 2011","Apr 2011","May 2011","Jun 2011","Jul 2011","Aug 2011","Sep 2011","Oct 2011","Nov 2011","Dec 2011",
                        "Jan 2012","Feb 2012","Mar 2012","Apr 2012","May 2012","Jun 2012","Jul 2012","Aug 2012","Sep 2012","Oct 2012","Nov 2012","Dec 2012",
                        "Jan 2013","Feb 2013","Mar 2013")
fct_count(mene3$my) # works

##############################CREATING DATASET WITH ONLY COMPLETE WEATHER CASES##############################

mene4 <- mene3[which(!is.na(mene3$DAY_MAX_TEMP) & !is.na(mene3$DAY_MAX_WINDSPEED) & !is.na(mene3$DAY_MAX_RAIN) & !is.na(mene3$day_length) & !is.na(mene3$METmins)),]
# excluding missing values for weather variables and MET minutes and visits to Wales (4) or unlocateable (19)
beep(8)

##############################PLOTTING WEATHER##############################

mene_temp_plot <- ggplot(mene4, aes(my, DAY_MAX_TEMP)) + stat_summary(aes(y=DAY_MAX_TEMP,group=1), fun.y=mean, geom="line", size=0.75) +
  ylab("Hourly max. air temperature during daylight (�C)") +
  theme(axis.text.x=element_text(angle=90, hjust=0.5, size=10), axis.title.x=element_blank(), axis.ticks.x=element_blank(),
        panel.background = element_blank(), panel.grid = element_blank(), panel.border = element_rect(fill=NA)) +
  scale_x_discrete(breaks = levels(mene4$my)[c(T, rep(F, 3))])
mene_wind_plot <- ggplot(mene4, aes(my, DAY_MAX_WINDSPEED)) + stat_summary(aes(y=DAY_MAX_WINDSPEED,group=1), fun.y=mean, geom="line", size=0.75)  +
  ylab("Hourly max. windspeed during daylight (m/s)") +
  theme(axis.text.x=element_text(angle=90, hjust=0.5, size=10), axis.title.x=element_blank(), axis.ticks.x=element_blank(),
        panel.background = element_blank(), panel.grid = element_blank(), panel.border = element_rect(fill=NA)) +
  scale_x_discrete(breaks = levels(mene4$my)[c(T, rep(F, 3))])
mene_rain_plot <- ggplot(mene4, aes(my, DAY_MAX_RAIN)) + stat_summary(aes(y=DAY_MAX_RAIN,group=1), fun.y=mean, geom="line", size=0.75)   +
  ylab("Hourly max. rainfall during daylight (mm/hours)") +
  theme(axis.text.x=element_text(angle=90, hjust=0.5, size=10), axis.title.x=element_blank(), axis.ticks.x=element_blank(),
        panel.background = element_blank(), panel.grid = element_blank(), panel.border = element_rect(fill=NA)) +
  scale_x_discrete(breaks = levels(mene4$my)[c(T, rep(F, 3))])
mene_daylight_plot <- ggplot(mene4, aes(my, day_lenth)) + stat_summary(aes(y=day_length,group=1), fun.y=mean, geom="line", size=0.75)   +
  ylab("Day length (hours)") +
  theme(axis.text.x=element_text(angle=90, hjust=0.5, size=10), axis.title.x=element_blank(), axis.ticks.x=element_blank(),
        panel.background = element_blank(), panel.grid = element_blank(), panel.border = element_rect(fill=NA)) +
  scale_x_discrete(breaks = levels(mene4$my)[c(T, rep(F, 3))])
mene_temp_plot
mene_rain_plot
mene_wind_plot
mene_daylight_plot

svg(file = paste("Figure 1a.svg"), width = 4, height = 5)
mene_temp_plot
dev.off()
dev.off()
dev.off()
svg(file = paste("Figure 1b.svg"), width = 4, height = 5)
mene_wind_plot
dev.off()
dev.off()
dev.off()
svg(file = paste("Figure 1c.svg"), width = 4, height = 5)
mene_rain_plot
dev.off()
dev.off()
dev.off()
svg(file = paste("Figure 1d.svg"), width = 4, height = 5)
mene_daylight_plot
dev.off()
dev.off()
dev.off()


##############################OTHER DESCRIPTIVES##############################

dtemp <- describeBy(mene4$DAY_MAX_TEMP, mene4$place4, mat=TRUE)[,c(2,4:6)]
dwind <- describeBy(mene4$DAY_MAX_WINDSPEED, mene4$place4, mat=TRUE)[,4:6]
drain <- describeBy(mene4$DAY_MAX_RAIN, mene4$place4, mat=TRUE)[,4:6]
dday <- describeBy(mene4$day_length, mene4$place4, mat=TRUE)[,4:6]
d1 <- cbind(dtemp,dwind,dday,drain)[1:4,]
d1

describeBy(mene4$METmins, mene4$place4, mat=TRUE)
describe(mene4$METmins)
  sqrt(var(mene4$METmins))
describe(mene4$DAY_MAX_TEMP)
describe(mene4$DAY_MAX_WINDSPEED)
describe(mene4$DAY_MAX_RAIN)
  sqrt(var(mene4$DAY_MAX_RAIN))
describe(mene4$day_length)


##############################UNADJUSTED REGRESSIONS##############################

# running unadjusted plus smooths and plotting them

unadj2gam <- gam(METmins ~ s(DAY_MAX_TEMP) + s(DAY_MAX_WINDSPEED) + rain_3cats + s(day_length), data=mene4, method="ML")
summary.gam(unadj2gam)
confint.default(unadj2gam)
  # and log-transform
unadj2gamLOG <- gam(METminsLOG ~ s(DAY_MAX_TEMP) + s(DAY_MAX_WINDSPEED) + rain_3cats + s(day_length), data=mene4, method="ML")
summary.gam(unadj2gamLOG)
confint.default(unadj2gamLOG)

concurvity(unadj2gam) # some concurvity of temperature and day length but not too much to worry about. A bit more for rainfall (0.67), but still okay.

e_unadj_temp <- visreg(unadj2gam, "DAY_MAX_TEMP", gg=TRUE, line=list(col='#E69F00'), fill=list(fill='#E69F00',alpha=0.25), partial=FALSE, rug=FALSE) +
  scale_y_continuous(name="Energy expenditure in natural environments\n(MET minutes)",limits=c(0,750)) +
  scale_x_continuous(name="Hourly max. temperature during daylight (�C)") +
  theme(panel.background = element_blank(), panel.grid = element_blank(), panel.border = element_rect(fill=NA))
f_unadj_wind <- visreg(unadj2gam, "DAY_MAX_WINDSPEED", gg=TRUE, line=list(col='#E69F00'), fill=list(fill='#E69F00',alpha=0.25), partial=FALSE, rug=FALSE) +
  scale_y_continuous(name="\n",limits=c(0,750)) +
  scale_x_continuous(name="Hourly max. wind speed during daylight (m/s)") +
  theme(panel.background = element_blank(), panel.grid = element_blank(), panel.border = element_rect(fill=NA))
g_unadj_rain <- visreg(unadj2gam, "rain_3cats", gg=TRUE, line=list(col='#E69F00'), fill=list(fill='#E69F00',alpha=0.25), partial=FALSE, rug=FALSE) +
  scale_y_continuous(name="\n",limits=c(0,750)) +
  xlab("Categories of hourly max. rainfall during daylight") +
  theme(panel.background = element_blank(), panel.grid = element_blank(), panel.border = element_rect(fill=NA))
h_unadj_daylength <- visreg(unadj2gam, "day_length", gg=TRUE, line=list(col='#E69F00'), fill=list(fill='#E69F00',alpha=0.25), partial=FALSE, rug=FALSE)  +
  scale_y_continuous(name="\n",limits=c(0,750)) +
  scale_x_continuous(name="Day length (hours)") +
  theme(panel.background = element_blank(), panel.grid = element_blank(), panel.border = element_rect(fill=NA))

svg(file = paste("Figure 1e.svg"), width = 4, height = 5)
e_unadj_temp
dev.off()
dev.off()
dev.off()
svg(file = paste("Figure 1f.svg"), width = 4, height = 5)
f_unadj_wind
dev.off()
dev.off()
dev.off()
svg(file = paste("Figure 1g.svg"), width = 4, height = 5)
g_unadj_rain
dev.off()
dev.off()
dev.off()
svg(file = paste("Figure 1h.svg"), width = 4, height = 5)
h_unadj_daylength
dev.off()
dev.off()
dev.off()

############################## ADJUSTED REGRESSIONS ##############################

# running adjusted model

adjgam <- gam(METmins ~ s(DAY_MAX_TEMP) + s(DAY_MAX_WINDSPEED) + rain_3cats + s(day_length) + sex + age_cats + SEGcombine + ethnic_cats +
                disability + marital_cats + work + children_in_hh + physical + wkday_wkend + local, data=mene4, method="ML")
summary.gam(adjgam)
confint.default(adjgam)
anova(unadj2gam,adjgam,test="F")

  # and log-transform
adjgamLOG <- gam(METminsLOG ~ s(DAY_MAX_TEMP) + s(DAY_MAX_WINDSPEED) + rain_3cats + s(day_length) + sex + age_cats + SEGcombine + ethnic_cats +
                disability + marital_cats + work + children_in_hh + physical + wkday_wkend + local, data=mene4, method="ML")
summary.gam(adjgamLOG)
confint.default(adjgamLOG)
anova(unadj2gamLOG,adjgamLOG,test="F")
  
# plotting them
  
  e_adj_temp <- visreg(adjgam, "DAY_MAX_TEMP", gg=TRUE, line=list(col='#56B4E9'), fill=list(fill='#56B4E9',alpha=0.25), partial=FALSE, rug=FALSE) +
    scale_y_continuous(name="Energy expenditure in natural environments\n(MET minutes)",limits=c(0,750)) +
    scale_x_continuous(name="Hourly max. temperature during daylight (�C)") +
    theme(panel.background = element_blank(), panel.grid = element_blank(), panel.border = element_rect(fill=NA))
  f_adj_wind <- visreg(adjgam, "DAY_MAX_WINDSPEED", gg=TRUE, line=list(col='#56B4E9'), fill=list(fill='#56B4E9',alpha=0.25), partial=FALSE, rug=FALSE)  +
    scale_y_continuous(name="\n",limits=c(0,750)) +
    scale_x_continuous(name="Hourly max. wind speed during daylight (m/s)") +
    theme(panel.background = element_blank(), panel.grid = element_blank(), panel.border = element_rect(fill=NA))
  g_adj_rain <- visreg(adjgam, "rain_3cats", gg=TRUE, line=list(col='#56B4E9'), fill=list(fill='#56B4E9',alpha=0.25), partial=FALSE, rug=FALSE)  +
    scale_y_continuous(name="\n",limits=c(0,750)) +
    xlab("Categories of hourly max. rainfall during daylight") +
    theme(panel.background = element_blank(), panel.grid = element_blank(), panel.border = element_rect(fill=NA))
  h_adj_daylength <- visreg(adjgam, "day_length", gg=TRUE, line=list(col='#56B4E9'), fill=list(fill='#56B4E9',alpha=0.25), partial=FALSE, rug=FALSE)  +
    scale_y_continuous(name="\n",limits=c(0,750)) +
    scale_x_continuous(name="Day length (hours)") +
    theme(panel.background = element_blank(), panel.grid = element_blank(), panel.border = element_rect(fill=NA))
  svg(file = paste("Figure 1ee.svg"), width = 4, height = 5)
  e_adj_temp
  dev.off()
  dev.off()
  dev.off()
  svg(file = paste("Figure 1ff.svg"), width = 4, height = 5)
  f_adj_wind
  dev.off()
  dev.off()
  dev.off()
  svg(file = paste("Figure 1gg.svg"), width = 4, height = 5)
  g_adj_rain
  dev.off()
  dev.off()
  dev.off()
  svg(file = paste("Figure 1hh.svg"), width = 4, height = 5)
  h_adj_daylength
  dev.off()
  dev.off()
  dev.off()
  
############################## ADJUSTED REGRESSIONS WITH INTERACTIONS NOW THE REDUCED FOUR CATEGORIES OF PLACE ##############################

fct_count(mene4$place4) # checking the numbers for such an interaction = 21,767

mene5 <- mene4[which(!is.na(mene4$place4)),] # creating a new dataset with just valid cases for place4

# for anova comparison

adj_gam2 <- gam(METmins ~ s(DAY_MAX_TEMP) + s(DAY_MAX_WINDSPEED) + rain_3cats + s(day_length) + sex + age_cats + SEGcombine + ethnic_cats +
                  disability + marital_cats + work + children_in_hh + physical + wkday_wkend + local, data=mene5, method="ML")
adj_gam2LOG <- gam(METminsLOG ~ s(DAY_MAX_TEMP) + s(DAY_MAX_WINDSPEED) + rain_3cats + s(day_length) + sex + age_cats + SEGcombine + ethnic_cats +
                  disability + marital_cats + work + children_in_hh + physical + wkday_wkend + local, data=mene5, method="ML")


# running adjusted model with interaction between 4 types of place and weather

adjgamint <- gam(METmins ~ s(DAY_MAX_TEMP) + s(DAY_MAX_WINDSPEED) + s(day_length) + s(DAY_MAX_TEMP, by=place4) + s(DAY_MAX_WINDSPEED, by=place4) + rain_3cats*place4 + s(day_length, by=place4) + sex + age_cats + SEGcombine + ethnic_cats +
                   disability + marital_cats + work + children_in_hh + physical + wkday_wkend + local, data=mene5, method="ML")
beep(8)
adjgamintLOG <- gam(METminsLOG ~ s(DAY_MAX_TEMP) + s(DAY_MAX_WINDSPEED) + s(day_length) + s(DAY_MAX_TEMP, by=place4) + s(DAY_MAX_WINDSPEED, by=place4) + rain_3cats*place4 + s(day_length, by=place4) + sex + age_cats + SEGcombine + ethnic_cats +
                   disability + marital_cats + work + children_in_hh + physical + wkday_wkend + local, data=mene5, method="ML")
beep(8)
summary(adjgamint)
summary(adjgamintLOG) # lots more sig spline terms
options(scipen=999)
confint.default(adjgamint)
confint.default(adjgamintLOG)
anova(adj_gam2,adjgamint,test="F") # interactions significantly improve the model
anova(adj_gam2LOG,adjgamintLOG,test="F")

##############################STRATIFIED REGRESSIONS BY REDUCED FOUR TYPES OF PLACE##############################

fct_count(mene5$place4)
menepark <- mene5[which(mene5$place4=="park"),]
menewoodland <- mene5[which(mene5$place4=="woodland"),]  
meneriver <- mene5[which(mene5$place4=="river"),]
menecoastal <- mene5[which(mene5$place4=="coast"),]

# parks

adj_parkgam <- gam(METmins ~ s(DAY_MAX_TEMP) + s(DAY_MAX_WINDSPEED) + rain_3cats + s(day_length) + sex + age_cats + SEGcombine + ethnic_cats +
                        disability + marital_cats + work + children_in_hh + physical + wkday_wkend + local, data=menepark, method="ML")
summary(adj_parkgam) # all linear
plot(adj_parkgam) # proves it
adj_park <- lm(METmins ~ DAY_MAX_TEMP + DAY_MAX_WINDSPEED + day_length + rain_3cats + sex + age_cats + SEGcombine + ethnic_cats +
                 disability + marital_cats + work + children_in_hh + physical + wkday_wkend + local, data=menepark) # running in case nothing else comes up
mutate(tidy(adj_park, conf.int=TRUE),signif = stars.pval(p.value))[c(1,2,6,7,8)] # basically the same as the overall relationship

adj_parkgamLOG <- gam(METminsLOG ~ s(DAY_MAX_TEMP) + s(DAY_MAX_WINDSPEED) + rain_3cats + s(day_length) + sex + age_cats + SEGcombine + ethnic_cats +
                     disability + marital_cats + work + children_in_hh + physical + wkday_wkend + local, data=menepark, method="ML")
summary(adj_parkgamLOG)
adj_parkLOG <- lm(METminsLOG ~ DAY_MAX_TEMP + DAY_MAX_WINDSPEED + day_length + rain_3cats + sex + age_cats + SEGcombine + ethnic_cats +
                    disability + marital_cats + work + children_in_hh + physical + wkday_wkend + local, data=menepark)
mutate(tidy(adj_parkLOG, conf.int=TRUE),signif=stars.pval(p.value))[c(1,2,6,7,8)] # holds
summary(adj_parkLOG)

# woods

adj_woodsgam <- gam(METmins ~ s(DAY_MAX_TEMP) + s(DAY_MAX_WINDSPEED) + rain_3cats + s(day_length) + sex + age_cats + SEGcombine + ethnic_cats +
                      disability + marital_cats + work + children_in_hh + physical + wkday_wkend + local, data=menewoodland, method="ML")
summary(adj_woodsgam) # only adylight - all linear
plot(adj_woodsgam) # proves it
adj_woods <- lm(METmins ~ DAY_MAX_TEMP + DAY_MAX_WINDSPEED + day_length + rain_3cats + sex + age_cats + SEGcombine + ethnic_cats +
                  disability + marital_cats + work + children_in_hh + physical + wkday_wkend + local, data=menewoodland)
mutate(tidy(adj_woods, conf.int=TRUE),signif=stars.pval(p.value))[c(1,2,6,7,8)] # only day length matters
summary(adj_woods)

adj_woodsgamLOG <- gam(METminsLOG ~ s(DAY_MAX_TEMP) + s(DAY_MAX_WINDSPEED) + rain_3cats + s(day_length) + sex + age_cats + SEGcombine + ethnic_cats +
                         disability + marital_cats + work + children_in_hh + physical + wkday_wkend + local, data=menewoodland, method="ML")
summary(adj_woodsgamLOG) # still all linear
adj_woodsLOG <- lm(METminsLOG ~ DAY_MAX_TEMP + DAY_MAX_WINDSPEED + day_length + rain_3cats + sex + age_cats + SEGcombine + ethnic_cats +
                     disability + marital_cats + work + children_in_hh + physical + wkday_wkend + local, data=menewoodland)
mutate(tidy(adj_woodsLOG, conf.int=TRUE),signif=stars.pval(p.value))[c(1,2,6,7,8)] # only day length matters
summary(adj_woodsLOG)

# rivers

adj_rivergam <- gam(METmins ~ s(DAY_MAX_TEMP) + s(DAY_MAX_WINDSPEED) + rain_3cats + s(day_length) + sex + age_cats + SEGcombine + ethnic_cats +
                      disability + marital_cats + work + children_in_hh + physical + wkday_wkend + local, data=meneriver, method="ML")
summary(adj_rivergam) # wind and daylength significant but all are linear
plot(adj_rivergam)
adj_river <- lm(METmins ~ DAY_MAX_TEMP + DAY_MAX_WINDSPEED + day_length + rain_3cats + sex + age_cats + SEGcombine + ethnic_cats +
                  disability + marital_cats + work + children_in_hh + physical + wkday_wkend + local, data=meneriver)
mutate(tidy(adj_river, conf.int=TRUE),signif=stars.pval(p.value))[c(1,2,6,7,8)] # windspeed and day length matter
summary(adj_river)

adj_rivergamLOG <- gam(METminsLOG ~ s(DAY_MAX_TEMP) + s(DAY_MAX_WINDSPEED) + rain_3cats + s(day_length) + sex + age_cats + SEGcombine + ethnic_cats +
                         disability + marital_cats + work + children_in_hh + physical + wkday_wkend + local, data=meneriver, method="ML")
summary(adj_rivergamLOG) # all pretty much linear again (bar temp)
adj_riverLOG <- lm(METminsLOG ~ DAY_MAX_TEMP + DAY_MAX_WINDSPEED + day_length + rain_3cats + sex + age_cats + SEGcombine + ethnic_cats +
                     disability + marital_cats + work + children_in_hh + physical + wkday_wkend + local, data=meneriver)
mutate(tidy(adj_riverLOG, conf.int=TRUE),signif=stars.pval(p.value))[c(1,2,6,7,8)] # holds
summary(adj_riverLOG)

# coasts

adj_coastalgam <- gam(METmins ~ s(DAY_MAX_TEMP) + s(DAY_MAX_WINDSPEED) + rain_3cats + s(day_length) + sex + age_cats + SEGcombine + ethnic_cats +
                        disability + marital_cats + work + children_in_hh + physical + wkday_wkend + local, data=menecoastal, method="ML")
summary(adj_coastalgam) # only temperature significant - all linear
plot(adj_coastalgam)
adj_coastal <- lm(METmins ~ DAY_MAX_TEMP + DAY_MAX_WINDSPEED + day_length + rain_3cats + sex + age_cats + SEGcombine + ethnic_cats +
                    disability + marital_cats + work + children_in_hh + physical + wkday_wkend + local, data=menecoastal)
mutate(tidy(adj_coastal, conf.int=TRUE),signif=stars.pval(p.value))[c(1,2,6,7,8)] # only temperature matters
summary(adj_coastal)

adj_coastalgamLOG <- gam(METminsLOG ~ s(DAY_MAX_TEMP) + s(DAY_MAX_WINDSPEED) + rain_3cats + s(day_length) + sex + age_cats + SEGcombine + ethnic_cats +
                           disability + marital_cats + work + children_in_hh + physical + wkday_wkend + local, data=menecoastal, method="ML")
summary(adj_coastalgamLOG) # same as above??? almost daylength
adj_coastalLOG <- lm(METminsLOG ~ DAY_MAX_TEMP + DAY_MAX_WINDSPEED + day_length + rain_3cats + sex + age_cats + SEGcombine + ethnic_cats +
                       disability + marital_cats + work + children_in_hh + physical + wkday_wkend + local, data=menecoastal)
mutate(tidy(adj_coastalLOG, conf.int=TRUE),signif=stars.pval(p.value))[c(1,2,6,7,8)] # holds
summary(adj_coastalLOG)

# checking multicollinearity

vif(adj_park)
vif(adj_woods)
vif(adj_river)
vif(adj_coastal)
vif(adj_parkLOG)
vif(adj_woodsLOG)
vif(adj_riverLOG)
vif(adj_coastalLOG)

results1 <- cbind(tidy(adj_park,conf.int=TRUE)[,c(1:4,6:7)],
      tidy(adj_woods,conf.int=TRUE)[,c(2:4,6:7)],
      tidy(adj_river,conf.int=TRUE)[,c(2:4,6:7)],
      tidy(adj_coastal,conf.int=TRUE)[,c(2:4,6:7)])
results1

# trying some standardised beta coefficients via the sjstats package

options(tibble.print_max = 50) # changes max number of rows in tibble outputs
std_beta(adj_park,ci.lvl=0.95)
std_beta(adj_woods,ci.lvl=0.95)
std_beta(adj_river,ci.lvl=0.95)
std_beta(adj_coastal,ci.lvl=0.95)

results2 <- rbind(std_beta(adj_park,ci.lvl=0.95)[,c(1:2,4:5)],
                  std_beta(adj_woods,ci.lvl=0.95)[,c(1:2,4:5)],
                  std_beta(adj_river,ci.lvl=0.95)[,c(1:2,4:5)],
                  std_beta(adj_coastal,ci.lvl=0.95)[,c(1:2,4:5)])
results2 <- data.frame(results2)
results2$model <- NA
results2$model[1:22] <- "Park\n(n=11988)"
results2$model[23:44] <- "Woodland\n(n=2947)"
results2$model[45:66] <- "Inland waters\n(n=2561)"
results2$model[67:88] <- "Coast\n(n=4271)"
results2$model <- factor(results2$model, levels=c("Park\n(n=11988)","Woodland\n(n=2947)","Inland waters\n(n=2561)","Coast\n(n=4271)"))
results2

############################## COVARIATES PLOT ##############################

results2$term <- factor(results2$term, levels=c("DAY_MAX_TEMP","DAY_MAX_WINDSPEED","day_length","rain_3catslight rain","rain_3catsmoderate/heavy rain","sexMale","age_cats35-64","age_cats65 and over",
                                                  "SEGcombineC1","SEGcombineC2","SEGcombineDE","ethnic_catsWhite British","disabilityYes","marital_catsMarried","workFull-time","workPart-time",
                                                  "workIn education","workRetired","children_in_hhAny","physical", "wkday_wkendWeekend","localFurther afield"))
results2$term <- fct_rev(results2$term)
levels(results2$term)

covplot <- ggplot(results2,aes(x=term, y=std.estimate)) +
  geom_point(shape=21, size=3, fill="black") +
  geom_errorbar(aes(ymin=conf.low, ymax=conf.high), width=0.1) +
  geom_hline(yintercept = 0) +
  scale_y_continuous(name="Standardised beta coefficient (MET-minutes)", limits=c(-0.15,0.3)) +
  scale_x_discrete(labels=c("Further afield visit (vs. local visit)","Weekend visit (vs. weekday visit)","Days of sufficient physical activity","Has children in household\n(vs. no children in household)","Retired (vs. not working)","In education (vs. not working)","Works part-time (vs. not working)",
                   "Works full-time (vs. not working)","Married (vs. not married)","Has long-standing illness/disability\n(vs. no long-standing illness/disability)","White-British (vs. all other ethnicities)","DE social grade (vs. AB social grade)","C2 social grade (vs. AB social grade)","C1 social grade (vs. AB social grade)","Aged 65 and over (vs. aged 16-34)",
                   "Aged 35-64 (vs. aged 16-34)","Males (vs. females)","Moderate/heavy rain (vs. no rain)","Light rain (vs. no rain)","Daylight hours","Wind speed","Temperature")) +
  geom_rect(xmin=as.numeric(results2$term[[1]])+0.4, xmax=as.numeric(results2$term[[5]])-0.4,ymin=-0.15,ymax=0.4,fill='#E69F00',alpha=0.01) +
  geom_rect(xmin=as.numeric(results2$term[[6]])+0.4, xmax=as.numeric(results2$term[[6]])-0.4,ymin=-0.15,ymax=0.4,fill='#56B4E9',alpha=0.01) +
  geom_rect(xmin=as.numeric(results2$term[[7]])+0.4, xmax=as.numeric(results2$term[[8]])-0.4,ymin=-0.15,ymax=0.4,fill='#56B4E9',alpha=0.01) +
  geom_rect(xmin=as.numeric(results2$term[[9]])+0.4, xmax=as.numeric(results2$term[[11]])-0.4,ymin=-0.15,ymax=0.4,fill='#56B4E9',alpha=0.01) +
  geom_rect(xmin=as.numeric(results2$term[[12]])+0.4, xmax=as.numeric(results2$term[[12]])-0.4,ymin=-0.15,ymax=0.4,fill='#56B4E9',alpha=0.01) +
  geom_rect(xmin=as.numeric(results2$term[[13]])+0.4, xmax=as.numeric(results2$term[[13]])-0.4,ymin=-0.15,ymax=0.4,fill='#56B4E9',alpha=0.01) +
  geom_rect(xmin=as.numeric(results2$term[[14]])+0.4, xmax=as.numeric(results2$term[[14]])-0.4,ymin=-0.15,ymax=0.4,fill='#56B4E9',alpha=0.01) +
  geom_rect(xmin=as.numeric(results2$term[[15]])+0.4, xmax=as.numeric(results2$term[[18]])-0.4,ymin=-0.15,ymax=0.4,fill='#56B4E9',alpha=0.01) +
  geom_rect(xmin=as.numeric(results2$term[[19]])+0.4, xmax=as.numeric(results2$term[[19]])-0.4,ymin=-0.15,ymax=0.4,fill='#56B4E9',alpha=0.01) +
  geom_rect(xmin=as.numeric(results2$term[[20]])+0.4, xmax=as.numeric(results2$term[[20]])-0.4,ymin=-0.15,ymax=0.4,fill='#56B4E9',alpha=0.01) +
  geom_rect(xmin=as.numeric(results2$term[[21]])+0.4, xmax=as.numeric(results2$term[[21]])-0.4,ymin=-0.15,ymax=0.4,fill='#009E73',alpha=0.01) +
  geom_rect(xmin=as.numeric(results2$term[[22]])+0.4, xmax=as.numeric(results2$term[[22]])-0.4,ymin=-0.15,ymax=0.4,fill='#009E73',alpha=0.01) +
  theme(panel.background = element_blank(), panel.grid = element_blank(), panel.border = element_rect(fill=NA),
        axis.title.y=element_blank(),axis.text.x = element_text(size=20),axis.text.y = element_text(size=15),
        axis.title.x=element_text(size=20), strip.text.x = element_text(size=20)) +
  coord_flip() +
  facet_wrap(~model, nrow = 1)
  covplot

pdf(file = paste("Figure 2.pdf"), paper = "special", width = 25, height = 16)
covplot
dev.off()
dev.off()
dev.off()

############################## ****OLD**** FUTURE PROJECTIONS ##############################

future <- read.csv("FUTURE.csv", header=TRUE) # reads in future projection data
lapply(future, FUN=class) # all numeric
mene4 <- plyr::rename(mene4, c("�..RespondentID"="Respondent_ID")) # renaming to match keyed variable
mene6 <- join(mene4, future, by="Respondent_ID") # joining by respondent ID
colnames(mene6) # the join has added the appropriate variables
head(mene6)[c(1,311:318)] # works

# overwriting environment data frames again

menepark <- mene6[which(mene6$place4=="park"),]
menewoodland <- mene6[which(mene6$place4=="woodland"),]  
meneriver <- mene6[which(mene6$place4=="river"),]
menecoastal <- mene6[which(mene6$place4=="coast"),]

# trying a new data frame for future

f_park <- menepark[,c(281,311:318)] # new park data frame with MET-mins and climate variables
f_woods <- menewoodland[,c(281,311:318)]
f_river <- meneriver[,c(281,311:318)]
f_coastal <- menecoastal[,c(281,311:318)]

# working out Met mins increases, LBs, UBs, and extremes

  # park

    # rcp45 2040
  
    f_park$MM_inc_rcp45_2040 <- f_park$rcp45_2040_mean * tidy(adj_park)[2,2]
    f_park$MM_inc_rcp45_2040_LB <- quantile(f_park$rcp45_2040_mean,.025) * tidy(adj_park)[2,2]
    f_park$MM_inc_rcp45_2040_UB <- quantile(f_park$rcp45_2040_mean,.975) * tidy(adj_park)[2,2]
    f_park$MM_inc_rcp45_2040_99 <- mean(f_park$rcp45_2040_99) * confint.default(adj_park,level=.98)[2,2]
    
    # rcp45 2090
    
    f_park$MM_inc_rcp45_2090 <- f_park$rcp45_2090_mean * tidy(adj_park)[2,2]
    f_park$MM_inc_rcp45_2090_LB <- quantile(f_park$rcp45_2090_mean,.025) * tidy(adj_park)[2,2]
    f_park$MM_inc_rcp45_2090_UB <- quantile(f_park$rcp45_2090_mean,.975) * tidy(adj_park)[2,2]
    f_park$MM_inc_rcp45_2090_99 <- mean(f_park$rcp45_2090_99) * confint.default(adj_park,level=.98)[2,2]
    
    # rcp85 2040
    
    f_park$MM_inc_rcp85_2040 <- f_park$rcp85_2040_mean * tidy(adj_park)[2,2]
    f_park$MM_inc_rcp85_2040_LB <- quantile(f_park$rcp85_2040_mean,.025) * tidy(adj_park)[2,2]
    f_park$MM_inc_rcp85_2040_UB <- quantile(f_park$rcp85_2040_mean,.975) * tidy(adj_park)[2,2]
    f_park$MM_inc_rcp85_2040_99 <- mean(f_park$rcp85_2040_99) * confint.default(adj_park,level=.98)[2,2]
    
    # rcp85 2090
    
    f_park$MM_inc_rcp85_2090 <- f_park$rcp85_2090_mean * tidy(adj_park)[2,2]
    f_park$MM_inc_rcp85_2090_LB <- quantile(f_park$rcp85_2090_mean,.025) * tidy(adj_park)[2,2]
    f_park$MM_inc_rcp85_2090_UB <- quantile(f_park$rcp85_2090_mean,.975) * tidy(adj_park)[2,2]
    f_park$MM_inc_rcp85_2090_99 <- mean(f_park$rcp85_2090_99) * confint.default(adj_park,level=.98)[2,2]
    
  # woods
    
    # rcp45 2040
    
    f_woods$MM_inc_rcp45_2040 <- f_woods$rcp45_2040_mean * tidy(adj_woods)[2,2]
    f_woods$MM_inc_rcp45_2040_LB <- quantile(f_woods$rcp45_2040_mean,.025) * tidy(adj_woods)[2,2]
    f_woods$MM_inc_rcp45_2040_UB <- quantile(f_woods$rcp45_2040_mean,.975) * tidy(adj_woods)[2,2]
    f_woods$MM_inc_rcp45_2040_99 <- mean(f_woods$rcp45_2040_99) * confint.default(adj_woods,level=.98)[2,2]
    
    # rcp45 2090
    
    f_woods$MM_inc_rcp45_2090 <- f_woods$rcp45_2090_mean * tidy(adj_woods)[2,2]
    f_woods$MM_inc_rcp45_2090_LB <- quantile(f_woods$rcp45_2090_mean,.025) * tidy(adj_woods)[2,2]
    f_woods$MM_inc_rcp45_2090_UB <- quantile(f_woods$rcp45_2090_mean,.975) * tidy(adj_woods)[2,2]
    f_woods$MM_inc_rcp45_2090_99 <- mean(f_woods$rcp45_2090_99) * confint.default(adj_woods,level=.98)[2,2]
    
    # rcp85 2040
    
    f_woods$MM_inc_rcp85_2040 <- f_woods$rcp85_2040_mean * tidy(adj_woods)[2,2]
    f_woods$MM_inc_rcp85_2040_LB <- quantile(f_woods$rcp85_2040_mean,.025) * tidy(adj_woods)[2,2]
    f_woods$MM_inc_rcp85_2040_UB <- quantile(f_woods$rcp85_2040_mean,.975) * tidy(adj_woods)[2,2]
    f_woods$MM_inc_rcp85_2040_99 <- mean(f_woods$rcp85_2040_99) * confint.default(adj_woods,level=.98)[2,2]
    
    # rcp85 2090
    
    f_woods$MM_inc_rcp85_2090 <- f_woods$rcp85_2090_mean * tidy(adj_woods)[2,2]
    f_woods$MM_inc_rcp85_2090_LB <- quantile(f_woods$rcp85_2090_mean,.025) * tidy(adj_woods)[2,2]
    f_woods$MM_inc_rcp85_2090_UB <- quantile(f_woods$rcp85_2090_mean,.975) * tidy(adj_woods)[2,2]
    f_woods$MM_inc_rcp85_2090_99 <- mean(f_woods$rcp85_2090_99) * confint.default(adj_woods,level=.98)[2,2]
    
  # river
    
    # rcp45 2040
    
    f_river$MM_inc_rcp45_2040 <- f_river$rcp45_2040_mean * tidy(adj_river)[2,2]
    f_river$MM_inc_rcp45_2040_LB <- quantile(f_river$rcp45_2040_mean,.025) * tidy(adj_river)[2,2]
    f_river$MM_inc_rcp45_2040_UB <- quantile(f_river$rcp45_2040_mean,.975) * tidy(adj_river)[2,2]
    f_river$MM_inc_rcp45_2040_99 <- mean(f_river$rcp45_2040_99) * confint.default(adj_river,level=.98)[2,2]
    
    # rcp45 2090
    
    f_river$MM_inc_rcp45_2090 <- f_river$rcp45_2090_mean * tidy(adj_river)[2,2]
    f_river$MM_inc_rcp45_2090_LB <- quantile(f_river$rcp45_2090_mean,.025) * tidy(adj_river)[2,2]
    f_river$MM_inc_rcp45_2090_UB <- quantile(f_river$rcp45_2090_mean,.975) * tidy(adj_river)[2,2]
    f_river$MM_inc_rcp45_2090_99 <- mean(f_river$rcp45_2090_99) * confint.default(adj_river,level=.98)[2,2]
    
    # rcp85 2040
    
    f_river$MM_inc_rcp85_2040 <- f_river$rcp85_2040_mean * tidy(adj_river)[2,2]
    f_river$MM_inc_rcp85_2040_LB <- quantile(f_river$rcp85_2040_mean,.025) * tidy(adj_river)[2,2]
    f_river$MM_inc_rcp85_2040_UB <- quantile(f_river$rcp85_2040_mean,.975) * tidy(adj_river)[2,2]
    f_river$MM_inc_rcp85_2040_99 <- mean(f_river$rcp85_2040_99) * confint.default(adj_river,level=.98)[2,2]
    
    # rcp85 2090
    
    f_river$MM_inc_rcp85_2090 <- f_river$rcp85_2090_mean * tidy(adj_river)[2,2]
    f_river$MM_inc_rcp85_2090_LB <- quantile(f_river$rcp85_2090_mean,.025) * tidy(adj_river)[2,2]
    f_river$MM_inc_rcp85_2090_UB <- quantile(f_river$rcp85_2090_mean,.975) * tidy(adj_river)[2,2]
    f_river$MM_inc_rcp85_2090_99 <- mean(f_river$rcp85_2090_99) * confint.default(adj_river,level=.98)[2,2]
    
  # coastal
    
    # rcp45 2040
    
    f_coastal$MM_inc_rcp45_2040 <- f_coastal$rcp45_2040_mean * tidy(adj_coastal)[2,2]
    f_coastal$MM_inc_rcp45_2040_LB <- quantile(f_coastal$rcp45_2040_mean,.025) * tidy(adj_coastal)[2,2]
    f_coastal$MM_inc_rcp45_2040_UB <- quantile(f_coastal$rcp45_2040_mean,.975) * tidy(adj_coastal)[2,2]
    f_coastal$MM_inc_rcp45_2040_99 <- mean(f_coastal$rcp45_2040_99) * confint.default(adj_coastal,level=.98)[2,2]
    
    # rcp45 2090
    
    f_coastal$MM_inc_rcp45_2090 <- f_coastal$rcp45_2090_mean * tidy(adj_coastal)[2,2]
    f_coastal$MM_inc_rcp45_2090_LB <- quantile(f_coastal$rcp45_2090_mean,.025) * tidy(adj_coastal)[2,2]
    f_coastal$MM_inc_rcp45_2090_UB <- quantile(f_coastal$rcp45_2090_mean,.975) * tidy(adj_coastal)[2,2]
    f_coastal$MM_inc_rcp45_2090_99 <- mean(f_coastal$rcp45_2090_99) * confint.default(adj_coastal,level=.98)[2,2]
    
    # rcp85 2040
    
    f_coastal$MM_inc_rcp85_2040 <- f_coastal$rcp85_2040_mean * tidy(adj_coastal)[2,2]
    f_coastal$MM_inc_rcp85_2040_LB <- quantile(f_coastal$rcp85_2040_mean,.025) * tidy(adj_coastal)[2,2]
    f_coastal$MM_inc_rcp85_2040_UB <- quantile(f_coastal$rcp85_2040_mean,.975) * tidy(adj_coastal)[2,2]
    f_coastal$MM_inc_rcp85_2040_99 <- mean(f_coastal$rcp85_2040_99) * confint.default(adj_coastal,level=.98)[2,2]
    
    # rcp85 2090
    
    f_coastal$MM_inc_rcp85_2090 <- f_coastal$rcp85_2090_mean * tidy(adj_coastal)[2,2]
    f_coastal$MM_inc_rcp85_2090_LB <- quantile(f_coastal$rcp85_2090_mean,.025) * tidy(adj_coastal)[2,2]
    f_coastal$MM_inc_rcp85_2090_UB <- quantile(f_coastal$rcp85_2090_mean,.975) * tidy(adj_coastal)[2,2]
    f_coastal$MM_inc_rcp85_2090_99 <- mean(f_coastal$rcp85_2090_99) * confint.default(adj_coastal,level=.98)[2,2]
    
# binding shit together in a graphable data frame
    
    means <- rbind(mean(f_park$MM_inc_rcp45_2040),
          mean(f_park$MM_inc_rcp45_2090),
          mean(f_park$MM_inc_rcp85_2040),
          mean(f_park$MM_inc_rcp85_2090),
          mean(f_woods$MM_inc_rcp45_2040),
          mean(f_woods$MM_inc_rcp45_2090),
          mean(f_woods$MM_inc_rcp85_2040),
          mean(f_woods$MM_inc_rcp85_2090),
          mean(f_river$MM_inc_rcp45_2040),
          mean(f_river$MM_inc_rcp45_2090),
          mean(f_river$MM_inc_rcp85_2040),
          mean(f_river$MM_inc_rcp85_2090),
          mean(f_coastal$MM_inc_rcp45_2040),
          mean(f_coastal$MM_inc_rcp45_2090),
          mean(f_coastal$MM_inc_rcp85_2040),
          mean(f_coastal$MM_inc_rcp85_2090))
    LBs <- rbind(mean(f_park$MM_inc_rcp45_2040_LB),
                 mean(f_park$MM_inc_rcp45_2090_LB),
                 mean(f_park$MM_inc_rcp85_2040_LB),
                 mean(f_park$MM_inc_rcp85_2090_LB),
                 mean(f_woods$MM_inc_rcp45_2040_LB),
                 mean(f_woods$MM_inc_rcp45_2090_LB),
                 mean(f_woods$MM_inc_rcp85_2040_LB),
                 mean(f_woods$MM_inc_rcp85_2090_LB),
                 mean(f_river$MM_inc_rcp45_2040_LB),
                 mean(f_river$MM_inc_rcp45_2090_LB),
                 mean(f_river$MM_inc_rcp85_2040_LB),
                 mean(f_river$MM_inc_rcp85_2090_LB),
                 mean(f_coastal$MM_inc_rcp45_2040_LB),
                 mean(f_coastal$MM_inc_rcp45_2090_LB),
                 mean(f_coastal$MM_inc_rcp85_2040_LB),
                 mean(f_coastal$MM_inc_rcp85_2090_LB))
    UBs <- rbind(mean(f_park$MM_inc_rcp45_2040_UB),
                 mean(f_park$MM_inc_rcp45_2090_UB),
                 mean(f_park$MM_inc_rcp85_2040_UB),
                 mean(f_park$MM_inc_rcp85_2090_UB),
                 mean(f_woods$MM_inc_rcp45_2040_UB),
                 mean(f_woods$MM_inc_rcp45_2090_UB),
                 mean(f_woods$MM_inc_rcp85_2040_UB),
                 mean(f_woods$MM_inc_rcp85_2090_UB),
                 mean(f_river$MM_inc_rcp45_2040_UB),
                 mean(f_river$MM_inc_rcp45_2090_UB),
                 mean(f_river$MM_inc_rcp85_2040_UB),
                 mean(f_river$MM_inc_rcp85_2090_UB),
                 mean(f_coastal$MM_inc_rcp45_2040_UB),
                 mean(f_coastal$MM_inc_rcp45_2090_UB),
                 mean(f_coastal$MM_inc_rcp85_2040_UB),
                 mean(f_coastal$MM_inc_rcp85_2090_UB))
    extremes <- rbind(mean(f_park$MM_inc_rcp45_2040_99),
                      mean(f_park$MM_inc_rcp45_2090_99),
                      mean(f_park$MM_inc_rcp85_2040_99),
                      mean(f_park$MM_inc_rcp85_2090_99),
                      mean(f_woods$MM_inc_rcp45_2040_99),
                      mean(f_woods$MM_inc_rcp45_2090_99),
                      mean(f_woods$MM_inc_rcp85_2040_99),
                      mean(f_woods$MM_inc_rcp85_2090_99),
                      mean(f_river$MM_inc_rcp45_2040_99),
                      mean(f_river$MM_inc_rcp45_2090_99),
                      mean(f_river$MM_inc_rcp85_2040_99),
                      mean(f_river$MM_inc_rcp85_2090_99),
                      mean(f_coastal$MM_inc_rcp45_2040_99),
                      mean(f_coastal$MM_inc_rcp45_2090_99),
                      mean(f_coastal$MM_inc_rcp85_2040_99),
                      mean(f_coastal$MM_inc_rcp85_2090_99))
    f <- data.frame(cbind(means,LBs,UBs,extremes))
    names(f) <- c("mean","LB","UB","extreme")
    f$place <- c("Park","Park","Park","Park","Woodland","Woodland","Woodland","Woodland",
                 "Inland waters","Inland waters","Inland waters","Inland waters","Coast","Coast","Coast","Coast")
    f$year <- c("2040","2090","2040","2090","2040","2090","2040","2090","2040","2090","2040","2090","2040","2090",
                "2040","2090")
    f$scenario <- c("RCP4.5","RCP4.5","RCP8.5","RCP8.5","RCP4.5","RCP4.5","RCP8.5","RCP8.5",
                    "RCP4.5","RCP4.5","RCP8.5","RCP8.5","RCP4.5","RCP4.5","RCP8.5","RCP8.5")
    
    # graphing it
    
    ggplot(f, aes(x=year,y=mean,ymin=mean,ymax=extremes,colour=scenario,group=scenario)) +
      geom_point(size=3,position=position_dodge(width=0.25)) +
      geom_line(size=0.75,position=position_dodge(width=0.25)) +
      geom_errorbar(width=0.1,size=0.75,position=position_dodge(width=0.25)) +
      facet_wrap(~f$place, scales="free_x") +
      xlab("") +
      ylab("Change in MET-minutes expended\n(compared to observed data)") +
      scale_color_manual(name="Climate\nscenario",values=c('#E69F00','#56B4E9')) +
      theme(text=element_text(size=20))
    
    
    
    
    
    
    
    
    
    
    
    
    
fff <- mene6  
fff$MM_inc_rcp45_2040 <- NA
fff$MM_inc_rcp45_2040[which(fff$place4=="coast")] <- fff$rcp45_2040_mean[which(fff$place4=="coast")] * tidy(adj_coastal)[2,2]
fff$MM_inc_rcp45_2040[which(fff$place4=="river")] <- fff$rcp45_2040_mean[which(fff$place4=="river")] * tidy(adj_river)[2,2]
fff$MM_inc_rcp45_2040[which(fff$place4=="park")] <- fff$rcp45_2040_mean[which(fff$place4=="park")] * tidy(adj_park)[2,2]
fff$MM_inc_rcp45_2040[which(fff$place4=="woodland")] <- fff$rcp45_2040_mean[which(fff$place4=="woodland")] * tidy(adj_woods)[2,2]

fff$MM_inc_rcp45_2090 <- NA
fff$MM_inc_rcp45_2090[which(fff$place4=="coast")] <- fff$rcp45_2090_mean[which(fff$place4=="coast")] * tidy(adj_coastal)[2,2]
fff$MM_inc_rcp45_2090[which(fff$place4=="river")] <- fff$rcp45_2090_mean[which(fff$place4=="river")] * tidy(adj_river)[2,2]
fff$MM_inc_rcp45_2090[which(fff$place4=="park")] <- fff$rcp45_2090_mean[which(fff$place4=="park")] * tidy(adj_park)[2,2]
fff$MM_inc_rcp45_2090[which(fff$place4=="woodland")] <- fff$rcp45_2090_mean[which(fff$place4=="woodland")] * tidy(adj_woods)[2,2]

fff$MM_inc_rcp85_2040 <- NA
fff$MM_inc_rcp85_2040[which(fff$place4=="coast")] <- fff$rcp85_2040_mean[which(fff$place4=="coast")] * tidy(adj_coastal)[2,2]
fff$MM_inc_rcp85_2040[which(fff$place4=="river")] <- fff$rcp85_2040_mean[which(fff$place4=="river")] * tidy(adj_river)[2,2]
fff$MM_inc_rcp85_2040[which(fff$place4=="park")] <- fff$rcp85_2040_mean[which(fff$place4=="park")] * tidy(adj_park)[2,2]
fff$MM_inc_rcp85_2040[which(fff$place4=="woodland")] <- fff$rcp85_2040_mean[which(fff$place4=="woodland")] * tidy(adj_woods)[2,2]

fff$MM_inc_rcp85_2090 <- NA
fff$MM_inc_rcp85_2090[which(fff$place4=="coast")] <- fff$rcp85_2090_mean[which(fff$place4=="coast")] * tidy(adj_coastal)[2,2]
fff$MM_inc_rcp85_2090[which(fff$place4=="river")] <- fff$rcp85_2090_mean[which(fff$place4=="river")] * tidy(adj_river)[2,2]
fff$MM_inc_rcp85_2090[which(fff$place4=="park")] <- fff$rcp85_2090_mean[which(fff$place4=="park")] * tidy(adj_park)[2,2]
fff$MM_inc_rcp85_2090[which(fff$place4=="woodland")] <- fff$rcp85_2090_mean[which(fff$place4=="woodland")] * tidy(adj_woods)[2,2]

# trying something different - using cis from ses in describeBy

tmp <- rbind(cbind(describeBy(fff$MM_inc_rcp45_2040,fff$place4,mat=T)[c(2,5)],1.96*describeBy(fff$MM_inc_rcp45_2040,fff$place4,mat=T)[15]),
             cbind(describeBy(fff$MM_inc_rcp45_2090,fff$place4,mat=T)[c(2,5)],1.96*describeBy(fff$MM_inc_rcp45_2090,fff$place4,mat=T)[15]),
             cbind(describeBy(fff$MM_inc_rcp85_2040,fff$place4,mat=T)[c(2,5)],1.96*describeBy(fff$MM_inc_rcp85_2040,fff$place4,mat=T)[15]),
             cbind(describeBy(fff$MM_inc_rcp85_2090,fff$place4,mat=T)[c(2,5)],1.96*describeBy(fff$MM_inc_rcp85_2090,fff$place4,mat=T)[15]))
names(tmp) <- c("place","mean","ci")
tmp$year <- c("2040","2040","2040","2040","2090","2090","2090","2090","2040","2040","2040","2040","2090","2090","2090","2090")
tmp$scenario <- c("RCP4.5","RCP4.5","RCP4.5","RCP4.5","RCP4.5","RCP4.5","RCP4.5","RCP4.5","RCP8.5","RCP8.5","RCP8.5","RCP8.5","RCP8.5","RCP8.5","RCP8.5","RCP8.5")
tmp$place <- factor(tmp$place, levels=c("park","woodland","river","coast"), labels=c("Park","Woodland","Inland waters","Coast"))

tmpplot <- ggplot(tmp, aes(x=year,y=mean,ymin=mean-ci,ymax=mean+ci,colour=scenario,group=scenario)) +
  geom_point(size=3,position=position_dodge(width=0.25)) +
  geom_line(size=0.75,position=position_dodge(width=0.25)) +
  geom_errorbar(width=0.1,size=0.75,position=position_dodge(width=0.25)) +
  facet_wrap(~tmp$place, scales="free_x") +
  xlab("") +
  ylab("Change in MET-minutes expended\n(compared to observed data)") +
  scale_color_manual(name="Climate\nscenario",values=c('#E69F00','#56B4E9')) +
  theme(text=element_text(size=20))
tmpplot

# this is the wrong way to do it - i.e. using the LBs and UBs as above but does create nice graphs

futdat <- rbind(cbind(describeBy(fff$MM_inc_rcp45_2040,fff$place4,mat=T)[c(2,5)]),
  cbind(describeBy(fff$MM_inc_rcp45_2090,fff$place4,mat=T)[c(2,5)]),
  cbind(describeBy(fff$MM_inc_rcp85_2040,fff$place4,mat=T)[c(2,5)]),
  cbind(describeBy(fff$MM_inc_rcp85_2090,fff$place4,mat=T)[c(2,5)]))
names(futdat) <- c("place","mean")
futdat$year <- c("2040","2040","2040","2040","2090","2090","2090","2090","2040","2040","2040","2040","2090","2090","2090","2090")
futdat$scenario <- c("RCP4.5","RCP4.5","RCP4.5","RCP4.5","RCP4.5","RCP4.5","RCP4.5","RCP4.5","RCP8.5","RCP8.5","RCP8.5","RCP8.5","RCP8.5","RCP8.5","RCP8.5","RCP8.5")
futdat$place <- factor(futdat$place, levels=c("park","woodland","river","coast"), labels=c("Park","Woodland","Inland waters","Coast"))
futdat <- data.frame(futdat)
futdat  
futplot <- ggplot(futdat, aes(x=year,y=mean,colour=scenario,group=scenario)) +
    geom_point(size=3,position=position_dodge(width=0.25)) +
    geom_line(size=0.75,position=position_dodge(width=0.25)) +
    facet_wrap(~futdat$place, scales="free_x",nrow = 1) +
    xlab("") +
    ylab("Change in MET-minutes expended\n(compared to observed data)") +
    scale_color_manual(name="Climate\nscenario",values=c('#E69F00','#56B4E9')) +
    theme(text=element_text(size=20))
futplot

# plot saving

pdf(file = paste("Figure 3.pdf"), paper = "special", width = 12, height = 12)
futplot
dev.off()
dev.off()
dev.off()


png(file = paste("Figure 3.png"), width = 2400, height = 800)
futplot
dev.off()
dev.off()
dev.off()

######################################################################################################################################